public class Main {
    public static void main(String[] args) {
        Shape[] shapes = {
                new Rectangle(4, 6),
                new Triangle(6, 8, 10),
                new Circle(3),
                new Square(5),
                new Rectangle(2, 8),
                new Triangle(5, 12, 13),
                new Circle(4.5),
                new Square(7),
                new Rectangle(7, 9),
                new Triangle(8, 15, 17),
                new Rectangle(3, 5),
                new Triangle(3, 4, 5),
                new Circle(2),
                new Square(4),
        };

        ShapeManager manager = new ShapeManager(shapes);
        Rectangle rectangle = manager.maxArea(Rectangle.class);
        Triangle triangle = manager.maxArea(Triangle.class);
        Circle circle = manager.maxArea(Circle.class);
        Square square = manager.maxArea(Square.class);
        
        System.out.println(rectangle);
        System.out.println(triangle);
        System.out.println(circle);
        System.out.println(square);
    }
}