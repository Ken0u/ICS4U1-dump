public class ShapeManager {
    private Shape[] shapes;
    public ShapeManager(Shape[] shapes) {
        this.shapes = shapes;
    }
    public <T extends Shape>T maxArea(Class<T> shapeClass) {
        Shape largestArea = null;

        for (int i = 0; i < shapes.length; i++) {
            Shape current = shapes[i];
            if (shapeClass == current.getClass()) {
                if (largestArea == null || current.compareToArea(largestArea) > 0) {
                    largestArea = current;
                }
            }
        }

        return (T) largestArea;
//        return shapeClass.cast(largestArea);
    }

    public <T extends Shape>T maxPerimeter(Class<T> shapeClass) {
        Shape largestPerimeter = null;

        for (int i = 0; i < shapes.length; i++) {
            Shape current = shapes[i];
            if (shapeClass == current.getClass()) {
                if (largestPerimeter == null || current.compareToPerimeter(largestPerimeter) > 0) {
                    largestPerimeter = current;
                }
            }
        }

        return (T) largestPerimeter;
//        return shapeClass.cast(largestPerimeter);
    }
}
