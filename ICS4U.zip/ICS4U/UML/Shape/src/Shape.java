public abstract class Shape {
    public abstract double area();
    public abstract double perimeter();
    public double compareToArea(Shape other) {
        return area() - other.area();
    }
    public double compareToPerimeter(Shape other) {
        return perimeter() - other.perimeter();
    }
    @Override
    public String toString() {
        return String.format("""
                Area: %f
                Perimeter: %f
                """, area(), perimeter());
    }
}
