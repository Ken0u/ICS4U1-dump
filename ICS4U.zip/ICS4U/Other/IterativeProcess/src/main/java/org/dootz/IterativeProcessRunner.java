package org.dootz;

public class IterativeProcessRunner {

    public static final String EXPRESSION = "x^2 - 2";
    public static final int TOTAL_ITERATIONS = 100;
    public static final int ROUNDING_PRECISION = 12;
    public static final int START = -5;
    public static final int END = 5;
    public static final double STEP = 0.001;


    public static void main(String[] args) {
        IterativeProcessGroup group = new IterativeProcessGroup();

        IterativeProcess trial1 = new IterativeProcess(EXPRESSION, 0, TOTAL_ITERATIONS, ROUNDING_PRECISION);
        IterativeProcess trial2 = new IterativeProcess(EXPRESSION, 1, TOTAL_ITERATIONS, ROUNDING_PRECISION);
        IterativeProcess trial3 = new IterativeProcess(EXPRESSION, 0.5, TOTAL_ITERATIONS, ROUNDING_PRECISION);
        IterativeProcess trial4 = new IterativeProcess(EXPRESSION, 0.2, TOTAL_ITERATIONS, ROUNDING_PRECISION);

        group.addAllProcesses(trial1, trial2, trial3, trial4);

        for (double i = START; i < END; i += STEP) {
            group.addProcess(new IterativeProcess(EXPRESSION, i, TOTAL_ITERATIONS, ROUNDING_PRECISION));
        }

        try {
            group.evaluate().toSpreadsheet("result.xlsx");
        } catch (Exception e) {
            System.out.println("An error has occurred.");
        }
    }
}