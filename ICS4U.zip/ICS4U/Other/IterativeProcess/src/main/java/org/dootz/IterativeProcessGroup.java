package org.dootz;

import com.ezylang.evalex.EvaluationException;
import com.ezylang.evalex.parser.ParseException;

import java.util.ArrayList;
import java.util.List;

public class IterativeProcessGroup {
    private List<IterativeProcess> processes;

    public IterativeProcessGroup(List<IterativeProcess> processes) {
        this.processes = processes;
    }

    public IterativeProcessGroup() {
        processes = new ArrayList<>();
    }

    public List<IterativeProcess> getProcesses() {
        return processes;
    }

    public void setProcesses(List<IterativeProcess> processes) {
        this.processes = processes;
    }

    public void addProcess(IterativeProcess process) {
        processes.add(process);
    }

    public void addAllProcesses(IterativeProcess... process) {
        processes.addAll(List.of(process));
    }

    public IterativeProcessGroupResult evaluate() throws EvaluationException, ParseException {
        List<IterativeProcessResult> results = new ArrayList<>();

        for (IterativeProcess process: processes) {
            results.add(process.evaluate());
        }

        return new IterativeProcessGroupResult(results);
    }
}
