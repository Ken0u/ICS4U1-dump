package org.dootz;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class IterativeProcessGroupResult {
    public static final String SHEET_TITLE = "Iterative Process";
    private final List<IterativeProcessResult> results;

    public IterativeProcessGroupResult(List<IterativeProcessResult> results) {
        this.results = results;
    }

    public IterativeProcessGroupResult() {
        results = new ArrayList<>();
    }

    public List<IterativeProcessResult> getResults() {
        return results;
    }

    public void addResult(IterativeProcessResult result) {
        results.add(result);
    }

    public int longestProcess() {
        IterativeProcessResult longestProcess = results.getFirst();

        for (IterativeProcessResult result: results) {
            if (result.compareToIterationCount(longestProcess) > 0) {
                longestProcess = result;
            }
        }

        return longestProcess.iterationCount();
    }

    private void createHeader(Workbook workbook) {
        Row header = workbook.getSheet(SHEET_TITLE).createRow(0);

        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setFillForegroundColor(new XSSFColor(new java.awt.Color(147, 168, 215), null));
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        Font subscript = new XSSFFont();
        subscript.setTypeOffset(Font.SS_SUB);

        for (int i = 0; i < longestProcess(); i++) {
            RichTextString iteration = new XSSFRichTextString(IterativeProcess.VARIABLE + i);
            iteration.applyFont(1, iteration.length(), subscript);
            Cell cell = header.createCell(i);
            cell.setCellValue(iteration);
            cell.setCellStyle(headerStyle);
        }
    }


    public void toSpreadsheet(String workbookName) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet(SHEET_TITLE);

            createHeader(workbook);

            for (int i = 0; i < results.size(); i++) {
                results.get(i).toSpreadsheet(workbook, i);
            }

            int largestColumnNumber = sheet.getRow(0).getLastCellNum();
            for (int i = 0; i < sheet.getLastRowNum(); i++) {
                int currentColumnNumber = sheet.getRow(i).getLastCellNum();
                if (currentColumnNumber > largestColumnNumber) {
                    largestColumnNumber = currentColumnNumber;
                }
            }

            for (int i = 0; i < largestColumnNumber; i++) {
                sheet.setColumnWidth(i, 256 * 16);
            }

            OutputStream output = new FileOutputStream(workbookName);
            workbook.write(output);
        }
    }
}
