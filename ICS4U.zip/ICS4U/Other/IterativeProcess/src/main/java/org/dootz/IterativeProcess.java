package org.dootz;

import com.ezylang.evalex.EvaluationException;
import com.ezylang.evalex.Expression;
import com.ezylang.evalex.config.ExpressionConfiguration;
import com.ezylang.evalex.parser.ParseException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

public class IterativeProcess {
    public static final String VARIABLE = "x";
    public static final BigDecimal LOWER_BOUND = new BigDecimal("-1e308");
    public static final BigDecimal UPPER_BOUND = new BigDecimal("1e308");
    private String expression;
    private BigDecimal initialValue;
    private int totalIterations;
    private int roundingPrecision;

    public IterativeProcess(String expression, double initialValue, int totalIterations, int roundingPrecision) {
        this.expression = expression;
        this.initialValue = BigDecimal.valueOf(initialValue);
        this.totalIterations = totalIterations;
        this.roundingPrecision = roundingPrecision;
    }
    public IterativeProcess(String expression, BigDecimal initialValue, int totalIterations, int roundingPrecision) {
        this.expression = expression;
        this.initialValue = initialValue;
        this.totalIterations = totalIterations;
        this.roundingPrecision = roundingPrecision;
    }

    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public BigDecimal getInitialValue() {
        return initialValue;
    }

    public void setInitialValue(double initialValue) {
        this.initialValue = BigDecimal.valueOf(initialValue);
    }

    public void setInitialValue(BigDecimal initialValue) {
        this.initialValue = initialValue;
    }

    public int getTotalIterations() {
        return totalIterations;
    }

    public void setTotalIterations(int totalIterations) {
        this.totalIterations = totalIterations;
    }

    public int getRoundingPrecision() {
        return roundingPrecision;
    }

    public void setRoundingPrecision(int roundingPrecision) {
        this.roundingPrecision = roundingPrecision;
    }

    public IterativeProcessResult evaluate() throws EvaluationException, ParseException {
        List<BigDecimal> values = new ArrayList<>(totalIterations);

        Expression expression = new Expression(this.expression, ExpressionConfiguration.builder().decimalPlacesRounding(roundingPrecision).build());
        expression.with(VARIABLE, initialValue);
        values.add(initialValue);

        BigDecimal currentValue = initialValue;
        for (int i = 0; i < totalIterations; i++) {
            currentValue = expression.evaluate().getNumberValue();

            if (currentValue.compareTo(LOWER_BOUND) < 0 || currentValue.compareTo(UPPER_BOUND) > 0) {
                currentValue = null;
            }

            if (currentValue != null) {
                expression.with(VARIABLE, currentValue);
            }

            values.add(currentValue);
        }

        return new IterativeProcessResult(values);
    }
}
