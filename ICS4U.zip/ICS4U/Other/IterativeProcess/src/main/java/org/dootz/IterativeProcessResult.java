package org.dootz;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.DefaultIndexedColorMap;
import org.apache.poi.xssf.usermodel.XSSFColor;

import java.awt.Color;
import java.math.BigDecimal;
import java.util.List;

public class IterativeProcessResult {
    private final List<BigDecimal> processValues;

    public IterativeProcessResult(List<BigDecimal> processValues) {
        this.processValues = processValues;
    }

    public List<BigDecimal> getProcessValues() {
        return processValues;
    }

    public int iterationCount() {
        return processValues.size();
    }

    public int compareToIterationCount(IterativeProcessResult other) {
        return iterationCount() - other.iterationCount();
    }

    public void toSpreadsheet(Workbook workbook, int processNumber) {
        Row row = workbook.getSheet(IterativeProcessGroupResult.SHEET_TITLE).createRow(processNumber + 1);

        CellStyle initialStyle = workbook.createCellStyle();
        initialStyle.setFillForegroundColor(new XSSFColor(new Color(183, 197, 223), null));

        initialStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        CellStyle otherStyle = workbook.createCellStyle();
        otherStyle.setFillForegroundColor(new XSSFColor(new Color(219, 225, 240), null));
        otherStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        for (int i = 0; i < processValues.size(); i++) {
            BigDecimal value = processValues.get(i);
            Cell cell = row.createCell(i);

            if (i == 0) {
                cell.setCellStyle(initialStyle);
            } else {
                cell.setCellStyle(otherStyle);
            }

            if (value == null) {
                cell.setCellValue("-");
            } else {
                cell.setCellValue(value.doubleValue());
            }

        }
    }
}
