abstract class A {
    public void xxx() {
        System.out.println("A.xxx");
    }
}

class B extends A {
    public void xxx() {
        System.out.println("B.xxx");
    }
}

public class Main {
    public static void main(String[] args) {
        B b = new B();
        ((A)b).xxx();
    }
}