public class Main {
    public static void main(String[] args) {
        Person p = new Student("A", 11);
        Student s = new Student("B", 12);
        
        boolean b = p.equals(s);
        System.out.println(b);
    }
}