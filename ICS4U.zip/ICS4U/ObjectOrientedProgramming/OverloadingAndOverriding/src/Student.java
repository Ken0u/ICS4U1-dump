public class Student extends Person{
    private int grade;
    public Student(String name, int grade) {
        super(name);
        this.grade = grade;
    }

    public boolean equals(Student student) {
        return true;
//        return grade == student.grade;
    }
    public boolean equals(Person p) {
        System.out.println("skjdlfasdkf");
        return true;
    }
}
