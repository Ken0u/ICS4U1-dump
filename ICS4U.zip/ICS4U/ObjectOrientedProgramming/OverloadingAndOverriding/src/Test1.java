 class A {
    public int method(Object o) {
        return 1;
    }

    public int method(A a) {
        return 2;
    }
}
 class AX extends A {
    public int method(A a) {
        return 3;
    }

    public int method(AX ax) {
        return 4;
    }
}

class AY extends AX {
    public int method(Object o) {
        return 5;
    }
}

 public class Test1{
     public static void main(String[] args) {
            Object o = new A();
            A a1 = new A();
            A a2 = new AX();
            AX ax = new AX();
    
            System.out.println(a1.method(o));
            System.out.println(a2.method(a1));
            System.out.println(a2.method(o));
            System.out.println(a2.method(ax));
            System.out.println(ax.method(o));
            
            AX ax2 = new AY();
            System.out.println(ax2.method(o));
     }
}
 