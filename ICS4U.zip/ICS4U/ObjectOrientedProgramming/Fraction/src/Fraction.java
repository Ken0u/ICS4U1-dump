import java.util.Arrays;

public class Fraction {
    private int numerator;
    private int denominator;
    public Fraction(){}
    public Fraction(double number) {
        denominator = 1;
        
        while (number % 1 != 0) {
            number *= 10;
            denominator *= 10;
        }
        numerator = (int) number;
        
        reduce();
    }
    public Fraction(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
    }

    public Fraction(Fraction other) {
        this.numerator = other.numerator;
        this.denominator = other.denominator;
    }
    
    public int getNumerator() {
        return numerator;
    }
    
    public int getDenominator() {
        return denominator;
    }
    
    public void setNumerator(int numerator) {
        this.numerator = numerator;
    }
    
    public void setDenominator(int denominator) {
        this.denominator = denominator;
    }
    
    public Fraction times(Fraction other) {
        return new Fraction(numerator * other.numerator, denominator * other.denominator);
    }
    
    public Fraction plus(Fraction other) {
        return new Fraction(numerator * other.denominator + other.numerator * 
                denominator, denominator * other.denominator);
    }
    
    public void timesEquals(Fraction other){
        numerator *= other.numerator;
        denominator *= other.denominator;
    }
    
    public void reduce() {
        int gcd = gcd(numerator, denominator);
        numerator /= gcd;
        denominator /= gcd;
    }
    private int gcd(int n, int d) {
        if (n == 0) {
            return d;
        }
        return gcd(d % n, n);
// slow
//        int start = Math.min(numerator, denominator);
//        int gcd = 1;
//
//        for (int i = start; i >= 2 && gcd == 1; i--) {
//            if (numerator % i == 0 && denominator % i == 0) {
//                gcd = i;
//            }
//        }
//        return gcd;
    }
    
    public static Fraction product(Fraction fraction1, Fraction fraction2) {
        return new Fraction(fraction1.numerator * fraction2.numerator, 
                fraction1.denominator * fraction2.denominator);
    }
    
    public static Fraction abs(Fraction fraction) {
        return new Fraction(Math.abs(fraction.numerator), Math.abs(fraction.denominator));
    }
    
    public static boolean isPositive(Fraction fraction) {
        return fraction.numerator > 0 == fraction.denominator > 0;
    }
    
    public boolean equals(Fraction other) {
        if (other != null) {
            reduce();
            other.reduce();
            return numerator == other.numerator && denominator == other.denominator;
        }
        return false;
    }
    
    @Override
    public String toString() {
        return numerator + "/" + denominator;
    }
    
}
