public class FractionRunner {
    public static void main(String[] args) {
        Fraction a = new Fraction(13, 5);
        System.out.println(a);

        Fraction b = new Fraction(0.98);
        System.out.println(b);

        Fraction c = new Fraction(8.343);
        System.out.println(c);

        Fraction d = new Fraction(2);
        System.out.println(d);
        
        Fraction e = new Fraction(4, 3);
        Fraction f = new Fraction(8, 6);
        
        System.out.println(e.equals(f));
        System.out.println(e.equals(null));
        System.out.println(e.equals(d));
        
    }
}