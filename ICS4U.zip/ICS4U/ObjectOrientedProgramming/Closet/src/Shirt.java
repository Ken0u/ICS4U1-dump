public class Shirt {
    private static final int CURRENT_YEAR = 2023;
    private String color;
    private int size;
    private int yearPurchased;
    public Shirt(String color, int size, int yearPurchased) {
        this.color = color;
        this.size = size;
        this.yearPurchased = yearPurchased;
    }
    public String getColor() {
        return color;
    }
    public int getSize() {
        return size;
    }
    public int getYearPurchased() {
        return yearPurchased;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public void setSize(int size) {
        this.size = size;
    }
    public void setYearPurchased(int yearPurchased) {
        this.yearPurchased = yearPurchased;
    }
    public int age() {
        return CURRENT_YEAR - yearPurchased;
    }
    public int compareToSize(Shirt other) {
        return size - other.size;
    }
    public int compareToAge(Shirt other) {
        return age() - other.age();
    }
    public boolean equals(Shirt other) {
        return other != null && color == other.color && size == other.size; 
    }
    public String toString() {
        return String.format("""
                Color: %s
                Size: %d
                Year Purchased: %d""", color, size, yearPurchased);
    }
    
}
