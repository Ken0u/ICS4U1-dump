import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ClosetRunner {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Closet closet;
        int maximumCapacity;
        String color;
        int size, yearOfPurchase;
        
        System.out.print("Enter the max capacity of the closet: ");
        maximumCapacity = sc.nextInt();
        sc.nextLine();
        closet = new Closet(maximumCapacity);
        
        try {
            BufferedReader br = new BufferedReader(new FileReader("boyShirts.txt"));
            
            int shirts = Integer.parseInt(br.readLine());
            for (int i = 0; i < shirts; i++) {
                color = br.readLine();
                size = Integer.parseInt(br.readLine());
                yearOfPurchase = Integer.parseInt(br.readLine());
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
        }
        
        System.out.println("Enter information for 5 shirts.");
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter color: ");
            color = sc.nextLine();
            System.out.print("Enter size: ");
            size = sc.nextInt();
            System.out.print("Enter year of purchase: ");
            yearOfPurchase = sc.nextInt();
            sc.nextLine();
            
            if (!closet.addShirt(color, size, yearOfPurchase)) {
                closet.removeOldestShirt();
                closet.addShirt(color, size, yearOfPurchase);
            }
        }
        
        System.out.print("Enter size to search: ");
        int searchSize = sc.nextInt();
        int count = closet.countShirtsBySize(searchSize);
        System.out.println("There are " + count + " shirts with size " + searchSize + ".");
        
        Shirt largestShirt = closet.largestShirt();
        System.out.println(largestShirt);
    }
}