public class Closet {
    private int maximumShirts;
    private int currentShirts;
    private Shirt[] shirts;
    public Closet(int maximumShirts) {
        this.maximumShirts = maximumShirts;
        currentShirts = 0;
        shirts = new Shirt[maximumShirts];
    }
    public boolean addShirt(String color, int size, int yearPurchased) {
        if (currentShirts == maximumShirts) {
            return false;
        }
        
        Shirt toBeAdded = new Shirt(color, size, yearPurchased);
        shirts[currentShirts] = toBeAdded;
        currentShirts++;
        return true;
    }
    public boolean removeOldestShirt() {
        if (currentShirts == 0) {
            return false;
        }
        
        int oldestIndex = indexOfOldestShirt();

        for (int i = oldestIndex; i < currentShirts - 1; i++) {
            shirts[i] = shirts[i + 1];
        }
        shirts[currentShirts - 1] = null;
        currentShirts--;
        return true;
    }
    private int indexOfOldestShirt() {
        
        int oldest = 0;
        for (int i = 0; i < currentShirts; i++) {
            if (shirts[i].compareToAge(shirts[oldest]) > 0) {
                oldest = i;
            }
        }
        return oldest;
    }
    public int countShirtsBySize(int size) {
        int count = 0;
        for (int i = 0; i < currentShirts; i++) {
            if (shirts[i].getSize() == size) {
                count++;
            }
        }
        return count;
    }
    public Shirt newestShirt() {
        if (currentShirts == 0) {
            return null;
        }
        
        Shirt newest = shirts[0];
        for (int i = 0; i < currentShirts; i++) {
            if (shirts[i].compareToAge(newest) < 0) {
                newest = shirts[i];
            }
        }
        return newest;
    }
    public Shirt largestShirt() {
        if (currentShirts == 0) {
            return null;
        }
        
        Shirt largest = shirts[0];
        for (int i = 0; i < currentShirts; i++) {
            if (shirts[i].compareToSize(largest) > 0) {
                largest = shirts[i];
            }
        }
        return largest;
    }
}
