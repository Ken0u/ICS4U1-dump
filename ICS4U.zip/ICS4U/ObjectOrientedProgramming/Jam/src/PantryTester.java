
import java.util.Scanner;

/**
 * Jam.java <br>
 * Stanley Gu <br>
 * ICS4U1 <br>
 * Tests the Jam and Pantry class.<br>
 */
public class PantryTester {
    public static void main(String[] args) {
        Jam jam1 = new Jam("Gooseberry", "7/4/86", 12);
        Jam jam2 = new Jam("Crab Apple", "9/30/99", 8);
        Jam jam3 = new Jam("Rhubarb", "10/31/99", 16);
        Pantry pantry = new Pantry(jam1, jam2, jam3);
        Scanner sc = new Scanner(System.in);
        int choice, oz;
        boolean exit = false;
        
        System.out.println("Welcome to Mother Hubbard's Pantry!");
        System.out.println(pantry);
        System.out.println("Enter your selection (1, 2, or 3): ");
        choice = sc.nextInt();
        while (!exit) {
            if (choice == -1) {
                exit = true;
                System.out.println("Good-bye");
            }
            
            if (!exit) {
                if (choice >= 1 && choice <= 3) {
                    System.out.println("Enter amount to spread: ");
                    oz = sc.nextInt();
                    pantry.spreadJar(choice, oz);
                } else {
                    System.out.println("Choice not in range.");
                }
                System.out.println();
                System.out.println("Welcome to Mother Hubbard's Pantry!");
                System.out.println(pantry);
                System.out.println("Enter your selection (1, 2, or 3): ");
                choice = sc.nextInt();
            }
        }
        
    }
}