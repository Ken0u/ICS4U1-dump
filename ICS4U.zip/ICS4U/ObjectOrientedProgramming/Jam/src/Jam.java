/**
 * Jam.java <br>
 * Stanley Gu <br>
 * ICS4U1 <br>
 * Represents a Jam jar.<br>
 */
public class Jam {
    /**
     * Instance Fields
     */
    private String content;
    private String date;
    private int oz;
    /**
     * Constructor for Jam with specified parameters.
     *
     * @param content The type or flavor of the jam.
     * @param date    The date the jam was made or acquired.
     * @param oz      The initial amount of fluid ounces in the jam jar.
     */
    public Jam(String content, String date, int oz) {
        this.content = content;
        this.date = date;
        this.oz = oz;
    }

    /**
     * Checks whether the jam jar is empty.
     *
     * @return {@code true} if the jar is empty (contains 0 fluid ounces of jam), {@code false} otherwise.
     */
    public boolean isEmpty() {
        return oz == 0;
    }

    /**
     * Spreads a specified amount of jam from the jar.
     *
     * If the jar is empty, a message is printed indicating that there is no jam.
     * Otherwise, the method limits the amount of jam to be spread based on the
     * current content in the jar and prints a message about the spreading action.
     *
     * @param oz The amount of fluid ounces of jam to spread.
     */
    public void spread(int oz) {
        if (isEmpty()) {
            System.out.println("No jam in the jar!");
        } else {
            oz = Math.min(oz, this.oz); // limits oz removed to amount of oz in the jar
            this.oz -= oz;
            System.out.printf("Spreading %d fluid ounces of %s.%n", oz, content);
        }
    }
    /**
     * Provides a string representation of the jam's details.
     *
     * @return A formatted string containing the information about the jam content, expiry date and fluid ounces.
     */
    public String toString() {
        return String.format("%s %s %d fl. oz.", content, date, oz);
    }
}
