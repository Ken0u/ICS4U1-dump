/**
 * Jam.java <br>
 * Stanley Gu <br>
 * ICS4U1 <br>
 * Represents a Pantry.<br>
 */
public class Pantry {
    /**
     * Instance fields
     */
    private Jam jar1;
    private Jam jar2;
    private Jam jar3;

    /**
     * Constructs a Pantry object with three Jam jars.
     *
     * @param jar1 The first Jam jar in the pantry.
     * @param jar2 The second Jam jar in the pantry.
     * @param jar3 The third Jam jar in the pantry.
     */
    public Pantry(Jam jar1, Jam jar2, Jam jar3) {
        this.jar1 = jar1;
        this.jar2 = jar2;
        this.jar3 = jar3;
    }
    /**
     * Spreads a specified amount of jam from the selected jar in the pantry. If the jar number
     * is invalid, no action will be done.
     *
     * @param jarNumber The number of the jar from which to spread jam (1, 2, or 3).
     * @param oz        The amount of fluid ounces of jam to spread.
     */
    public void spreadJar(int jarNumber, int oz) {
        switch(jarNumber) {
            case 1 -> jar1.spread(oz);
            case 2 -> jar2.spread(oz);
            case 3 -> jar3.spread(oz);
        }
    }
    /**
     * Returns a formatted string representation of the Pantry, including information about each Jam jar.
     *
     * @return A string containing information about the jams in the pantry.
     */
    public String toString() {
        return String.format("""
               The jams are:
               1: %s
               2: %s
               3: %s""", jar1, jar2, jar3);
    }
}
