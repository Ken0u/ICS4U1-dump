import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 * Stanley Gu <br>
 * ICS4U <br>
 * BagTester.java <br>
 * Tests the Binder and SchoolBag classes.
 */
public class BagTester {
    public static void main(String[] args) {
        String label1, color1;
        int pages1;
        String label2, color2;
        int pages2;
        Binder binder1;
        Binder binder2;
        
        String style;
        SchoolBag schoolBag1 = null;
        SchoolBag schoolBag2 = null;
        try {
            BufferedReader br = new BufferedReader(new FileReader("data.txt"));
            
            style = br.readLine();
            String[] info = br.readLine().split(" ");
            label1 = info[0];
            color1 = info[1];
            pages1 = Integer.parseInt(info[2]);
            info = br.readLine().split(" ");
            label2 = info[0];
            color2 = info[1];
            pages2 = Integer.parseInt(info[2]);
            
            binder1 = new Binder(label1, color1, pages1);
            binder2 = new Binder(label2, color2, pages2);
            schoolBag1 = new SchoolBag(style, binder1, binder2);

            style = br.readLine();
            info = br.readLine().split(" ");
            label1 = info[0];
            color1 = info[1];
            pages1 = Integer.parseInt(info[2]);
            info = br.readLine().split(" ");
            label2 = info[0];
            color2 = info[1];
            pages2 = Integer.parseInt(info[2]);
            
            schoolBag2 = new SchoolBag(style, label1, color1, pages1, label2, color2, pages2);
            
        } catch (IOException e) {
            System.out.println("An error occurred.");
        }
        
        Scanner sc = new Scanner(System.in);
        int schoolBagId, binderId, sheets;
        char action;
        
        System.out.print("Please select a schoolbag (by ID, 1 or 2): ");
        schoolBagId = sc.nextInt();
        while (schoolBagId != -1) {
            System.out.printf("Please select a binder in schoolbag %d (by ID, 1 or 2): ", schoolBagId);
            binderId = sc.nextInt();
            sc.nextLine();
            System.out.print("Add (a) or remove (r) sheets: ");
            action = sc.nextLine().charAt(0);
            System.out.print("# of sheets: ");
            sheets = sc.nextInt();
            
            switch (schoolBagId) {
                case 1 -> {
                    switch(action) {
                        case 'a' -> schoolBag1.addSheetsToBinder(binderId, sheets);
                        case 'r' -> schoolBag1.removeSheetsFromBinder(binderId, sheets);
                    }
                }
                case 2 -> {
                    switch(action) {
                        case 'a' -> schoolBag2.addSheetsToBinder(binderId, sheets);
                        case 'r' -> schoolBag2.removeSheetsFromBinder(binderId, sheets);
                    }
                }
            }

            System.out.println();
            System.out.print("Please select a schoolbag (by ID, 1 or 2): ");
            schoolBagId = sc.nextInt();
        }
        
        System.out.println("SchoolBag #1");
        System.out.println(schoolBag1);
        System.out.println("SchoolBag #2");
        System.out.println(schoolBag2);
    }
}