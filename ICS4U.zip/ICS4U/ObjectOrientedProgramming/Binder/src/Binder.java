/**
 * Stanley Gu <br>
 * ICS4U <br>
 * Binder.java <br>
 * Represents a binder with a label, color and number of sheets.
 */
public class Binder {
    /**
     * Class fields
     */
    private static final int SHEET_WEIGHT = 5; // in grams
    private static final int EMPTY_BINDER_WEIGHT = 250;
    /**
     * Instance fields
     */
    private String label;
    private String color;
    private int sheets;
    /**
     * Constructs a new Binder with the specified label, color, and initial number of sheets.
     *
     * @param label  the label of the binder
     * @param color  the color of the binder
     * @param sheets the initial number of sheets in the binder
     */
    public Binder(String label, String color, int sheets) {
        this.label = label;
        this.color = color;
        this.sheets = sheets;
    }
    /**
     * Adds the specified number of sheets to the binder.
     *
     * @param sheets the number of sheets to add
     */
    public void addSheets(int sheets) {
        this.sheets += sheets;
    }
    /**
     * Removes the specified number of sheets from the binder.
     *
     * @param sheets the number of sheets to remove
     * @return {@code true} if the sheets were successfully removed, {@code false} if more sheets were requested
     *         for removal than the total number of sheets in the binder
     */
    public boolean removeSheets(int sheets) {
        if (this.sheets - sheets < 0) { // if more sheets can be removed than sheets in binder
            this.sheets = 0;
            return false;
        } else {
            this.sheets -= sheets;
            return true;
        }
    }
    /**
     * Calculates and returns the total weight of the binder, including sheets and empty binder weight.
     *
     * @return the total weight of the binder in grams
     */
    public int totalWeight() {
        return sheets * SHEET_WEIGHT + EMPTY_BINDER_WEIGHT; 
    }
    /**
     * Compares this binder with another binder based on their total weights.
     *
     * @param other the binder to compare to
     * @return a negative integer, zero, or a positive integer as this binder is less than, equal to,
     *         or greater than the specified binder
     */
    public int compareTo(Binder other) { 
        return totalWeight() - other.totalWeight(); 
    }
    /**
     * Returns a formatted string representation of the binder, including its label, color, and number of sheets.
     *
     * @return a string representation of the binder
     */
    public String toString() {
        return String.format("""
                \tLabel: %s
                \tColor: %s
                \t# of sheets: %d""", label, color, sheets);
    }
    
}
