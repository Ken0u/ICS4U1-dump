/**
 * Stanley Gu <br>
 * ICS4U <br>
 * Schoolbag.java <br>
 * Represents a schoolbag with a style and 2 binders.
 */
public class SchoolBag {
    /**
     * Instance fields
     */
    private String style;
    private Binder binder1;
    private Binder binder2;
    private static final int EMPTY_SCHOOL_BAG_WEIGHT = 1250; // in grams
    /**
     * Constructs a new SchoolBag with the specified style and two binders.
     *
     * @param style   the style of the school bag
     * @param binder1 the first binder in the school bag
     * @param binder2 the second binder in the school bag
     */
    public SchoolBag(String style, Binder binder1, Binder binder2) {
        this.style = style;
        this.binder1 = binder1;
        this.binder2 = binder2;
    }
    /**
     * Constructs a new SchoolBag with the specified style and creates two binders with the provided
     * labels, colors, and initial number of sheets.
     *
     * @param style  the style of the school bag
     * @param label1 the label of the first binder
     * @param color1 the color of the first binder
     * @param sheets1 the initial number of sheets in the first binder
     * @param label2 the label of the second binder
     * @param color2 the color of the second binder
     * @param sheets2 the initial number of sheets in the second binder
     */
    public SchoolBag(String style, String label1, String color1, int sheets1, String label2, String color2, int sheets2) {
        this.style = style;
        this.binder1 = new Binder(label1, color1, sheets1);
        this.binder2 = new Binder(label2, color2, sheets2);
    }

    /**
     * Adds the specified number of sheets to the designated binder in the school bag.
     *
     * @param binderNumber the number of the binder (1 or 2)
     * @param sheets       the number of sheets to add
     */
    public void addSheetsToBinder(int binderNumber, int sheets) {
        switch(binderNumber) {
            case 1 -> binder1.addSheets(sheets);
            case 2 -> binder2.addSheets(sheets);
        }
    }
    /**
     * Removes the specified number of sheets from the designated binder in the school bag.
     *
     * @param binderNumber the number of the binder (1 or 2)
     * @param sheets       the number of sheets to remove
     * @return {@code true} if the sheets were successfully removed,
     *         {@code false} if more sheets were requested for removal than the total number of sheets in the binder
     */
    public boolean removeSheetsFromBinder(int binderNumber, int sheets) {
        return switch(binderNumber) {
            case 1 -> binder1.removeSheets(sheets);
            case 2 -> binder2.removeSheets(sheets);
            default -> false;
        };
    }
    /**
     * Calculates and returns the average weight of the binders in the school bag.
     *
     * @return the average weight of the binders in the school bag in grams
     */
    public int averageWeight() {
        return (binder1.totalWeight() + binder2.totalWeight()) / 2;
    }
    /**
     * Calculates and returns the total weight of the school bag, including the weight of the
     * empty school bag and the total weight of the binders.
     *
     * @return the total weight of the school bag in grams
     */
    public int totalWeight() {
        return EMPTY_SCHOOL_BAG_WEIGHT + binder1.totalWeight() + binder2.totalWeight();
    }
    /**
     * Returns a formatted string representation of the school bag, including its style and details
     * of the binders inside.
     *
     * @return a string representation of the school bag
     */
    public String toString() {
        return String.format("""
                Style: %s
                Binder #1 - 
                %s
                Binder #2 -
                %s""", style, binder1, binder2);
    }
}
