import java.util.Scanner;
/**
 * ICS4U <br>
 * Stanley Gu <br>
 * 11/28/23 <br>
 * PayrollRunner.java <br>
 *
 * Tests the Employee, PartTimeStaff, FullTimeStaff, and Payroll classes.
 */
public class PayrollRunner {
    public static void main(String[] args) {
        Payroll payroll = new Payroll();
        Scanner sc = new Scanner(System.in);
        String menu = """
                1. List All Employees
                2. Enter Sick Day (Update Sick Day Information)
                3. Print All Pay Stubs
                4. Save Staff List
                5. Load Staff List
                6. Calculate Average Salary of Full-time Staff
                7. Calculate Average Hourly Rate of Part-time Staff
                8. Find Most Absent Full-time Staff in Current Year
                9. Find Most Absent Part-time Staff in Current Month
                10. Yearly Sick Day Reset for Full-time Staff
                11. Monthly Sick Day Reset for Part-time Staff
                12. Exit
                            
                Please enter the number corresponding to your choice:\s""";
        
        
        System.out.print(menu);
        int choice = sc.nextInt();
        
        while (choice != 12) {
            switch (choice) {
                case 1 -> payroll.listAllEmployees();
                case 2 -> {
                    sc.nextLine();
                    System.out.print("Enter Employee Number: ");
                    String employeeNumber = sc.nextLine();
                    System.out.print("Enter sick days to deduct: ");
                    int sickDays = sc.nextInt();
                    payroll.enterSickDays(employeeNumber, sickDays);
                    sc.nextLine();
                }
                case 3 -> payroll.printAllPayStubs();
                case 4 -> payroll.saveStaffList();
                case 5 -> payroll.loadStaffList();
                case 6 -> {
                    double averageSalary = payroll.averageSalary();
                    System.out.printf("Average salary for full time staff is $%.2f%n", averageSalary);
                }
                case 7 -> {
                    double averageHourlyRate = payroll.averageHourlyRate();
                    System.out.printf("Average hourly rate for part time staff is $%.2f%n", averageHourlyRate);
                }
                case 8 -> {
                    FullTimeStaff mostAbsentFullTime = payroll.mostAbsentFullTime();
                    System.out.println("The most absent full time staff is: ");
                    System.out.println(mostAbsentFullTime);
                }
                case 9 -> {
                    PartTimeStaff mostAbsentPartTime = payroll.mostAbsentPartTime();
                    System.out.println("The most absent part time staff is: ");
                    System.out.println(mostAbsentPartTime);
                }
                case 10 -> {
                    payroll.yearlySickDayReset();
                    System.out.println("All full time staff sick days have been reset.");
                }
                case 11 -> {
                    payroll.monthlySickDayReset();
                    System.out.println("All part time staff sick days have been reset.");
                }
                default -> System.out.println("Not an option. Try again.");
            }
            System.out.print(menu);
            choice = sc.nextInt();
        }
    }
}