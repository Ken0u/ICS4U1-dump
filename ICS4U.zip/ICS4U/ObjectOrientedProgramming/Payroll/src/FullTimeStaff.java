/**
 * ICS4U <br>
 * Stanley Gu <br>
 * 11/28/23 <br>
 * FullTimeStaff.java <br>
 *
 * Represents a full-time staff member, extending the Employee class.
 */
public class FullTimeStaff extends Employee {
    /**
     * Class fields
     */
    public static final String TITLE = "Full-Time";
    private static final double YEARLY_SICK_DAYS = 20;
    private static final int MONTHS = 12;
    /**
     * Instance fields
     */
    private double yearlySalary;
    private double sickDaysLeft;
    /**
     * Constructs a FullTimeStaff object with the given parameters.
     *
     * @param employeeNumber The employee number.
     * @param firstName      The first name of the employee.
     * @param lastName       The last name of the employee.
     * @param yearlySalary   The yearly salary for the full-time staff.
     * @param sickDaysLeft   The remaining sick days for the full-time staff.
     */
    public FullTimeStaff(String employeeNumber, String firstName, String lastName,
                         double yearlySalary, double sickDaysLeft) {
        super(employeeNumber, firstName, lastName);
        this.yearlySalary = yearlySalary;
        this.sickDaysLeft = sickDaysLeft;
    }
    /**
     * Gets the yearly salary for the full-time staff.
     *
     * @return The yearly salary.
     */
    public double getYearlySalary() {
        return yearlySalary;
    }
    /**
     * Calculates and returns the monthly pay for the full-time staff.
     *
     * @return The monthly pay for the full-time staff.
     */
    @Override
    public double pay() {
        return yearlySalary / MONTHS;
    }
    /**
     * Deducts the specified number of sick days from the remaining sick days.
     * Displays an error message if there are not enough sick days available.
     *
     * @param sickDays The number of sick days to deduct.
     */
    @Override
    public void deductSickDays(double sickDays) {
        if (sickDaysLeft - sickDays < 0) {
            System.out.println("Not enough sick days.");
        } else {
            sickDaysLeft -= sickDays;
        }
    }
    /**
     * Resets the remaining sick days to the yearly allocation.
     */
    @Override
    public void resetSickDays() {
        sickDaysLeft = YEARLY_SICK_DAYS;
    }
    /**
     * Prints the pay stub for the full-time staff, including amount earned and sick days left.
     */
    @Override
    public void printPayStub() {
        super.printPayStub();
        System.out.printf("""
                \tAmount Earned: $%.2f
                \tSick Days Left: %.1f
                """, pay(), sickDaysLeft);
    }
    /**
     * Compares the remaining sick days of this full-time staff with another full-time staff. {@code other} cannot be null.
     *
     * @param other The other FullTimeStaff object to compare.
     * @return The difference in remaining sick days.
     */
    public double compareToSickDays(FullTimeStaff other) {
        return sickDaysLeft - other.sickDaysLeft;
    }
    /**
     * Generates a string representation of the full-time staff, including title, basic information,
     * yearly salary, and remaining sick days.
     *
     * @return The string representation of the full-time staff.
     */
    @Override
    public String toString() {
        return String.format("\tTitle: %s\n", TITLE) + super.toString() + String.format("""
                    \tYearly Salary: $%.2f/yr
                    \tSick Days Left: %.1f""", yearlySalary, sickDaysLeft);
    }
    /**
     * Converts the full-time staff information to a string suitable for data storage or transmission.
     *
     * @return The string representation of the full-time staff for data purposes.
     */
    @Override
    public String toData() {
        return TITLE + '\n' + super.toData() + yearlySalary + '\n' + sickDaysLeft;
    }
}
