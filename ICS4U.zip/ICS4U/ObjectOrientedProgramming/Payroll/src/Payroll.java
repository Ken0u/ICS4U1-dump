import java.io.*;
/**
 * ICS4U <br>
 * Stanley Gu <br>
 * 11/28/23 <br>
 * Payroll.java <br>
 *
 * Represents a payroll system managing a list of employees. Provides functionality
 * to list employees, deduct sick days, print pay stubs, save/load staff list to/from
 * a file, calculate average salaries and hourly rates, and manage sick day resets.
 */
public class Payroll {
    /**
     * Class fields
     */
    private static final String FILE_NAME = "employees.txt";
    /**
     * Instance fields
     */
    private Employee[] staffList;
    /**
     * Displays information for all employees in the staff list.
     */
    public void listAllEmployees() {
        
        System.out.println("Employees");
        for (int i = 0; i < staffList.length; i++) {
            System.out.printf("Employee #%d%n", i);
            System.out.println(staffList[i]);
        }
    }
    /**
     * Deducts sick days for a specific employee identified by employee number.
     *
     * @param employeeNumber  The employee number of the employee.
     * @param sickDaysToDeduct The number of sick days to deduct.
     */
    public void enterSickDays(String employeeNumber, int sickDaysToDeduct) {
        
        int index = indexOfEmployeeNumber(employeeNumber);
        if (index == -1) {
            System.out.println("Employee does not exist.");
            return;
        }
        Employee employee = staffList[index];
        employee.deductSickDays(sickDaysToDeduct);
        System.out.println("Changed employee sick days.");
    }
    /**
     * Prints pay stubs for all employees in the staff list.
     */
    public void printAllPayStubs() {
        System.out.println("Pay Stubs");
        for (int i = 0; i < staffList.length; i++) {
            staffList[i].printPayStub();
        }
    }
    /**
     * Saves the staff list to a file named "employees.txt".
     */
    public void saveStaffList() {
        
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME));
            int length = staffList.length;
            
            bw.write(""+length);
            bw.newLine();
            
            for (int i = 0; i < length; i++) {
                bw.write(staffList[i].toData());
                bw.newLine();
            }
            bw.close();

            System.out.println("Successfully saved staff to file.");
        } catch (IOException e) {
            System.out.println("An error occurred when saving.");
        }
    }
    /**
     * Loads the staff list from a file named "employees.txt".
     */
    public void loadStaffList() {
        try {
            BufferedReader br = new BufferedReader(new FileReader(FILE_NAME));
            int numStaff = Integer.parseInt(br.readLine());
            staffList = new Employee[numStaff];
            
            for (int i = 0; i < numStaff; i++) {
                
                String title = br.readLine();
                String employeeNumber = br.readLine();
                String firstName = br.readLine();
                String lastName = br.readLine();
                
                switch (title) {
                    case FullTimeStaff.TITLE -> {
                        double yearlySalary = Double.parseDouble(br.readLine());
                        double sickDaysLeft = Double.parseDouble(br.readLine());
                        staffList[i] = new FullTimeStaff(employeeNumber, firstName, lastName, yearlySalary, sickDaysLeft);
                    }
                    case PartTimeStaff.TITLE -> {
                        double numHoursAssigned = Double.parseDouble(br.readLine());
                        double hourlyRate = Double.parseDouble(br.readLine());
                        double sickDaysTaken = Double.parseDouble(br.readLine());
                        staffList[i] = new PartTimeStaff(employeeNumber, firstName, lastName, numHoursAssigned, hourlyRate, sickDaysTaken);
                    }
                }
            } 
            
            br.close();
            System.out.println("Successfully loaded staff from file.");
        } catch (IOException e) {
            System.out.println("An error occurred when loading.");
        }
    }
    /**
     * Calculates the average yearly salary for full-time staff in the staff list.
     *
     * @return The average yearly salary for full-time staff.
     */
    public double averageSalary() {
        double sum = 0;
        int fullTimeStaff = 0;
        for (int i = 0; i < staffList.length; i++) {
            Employee employee = staffList[i];
            if (employee instanceof FullTimeStaff staff) {
                sum += staff.getYearlySalary();
                fullTimeStaff++;
            } 
        }
        return sum / fullTimeStaff;
    }
    /**
     * Calculates the average hourly rate for part-time staff in the staff list.
     *
     * @return The average hourly rate for part-time staff.
     */
    public double averageHourlyRate() {
        double sum = 0;
        int partTimeStaff = 0;
        for (int i = 0; i < staffList.length; i++) {
            Employee employee = staffList[i];
            if (employee instanceof PartTimeStaff staff) {
                sum += staff.getHourlyRate();
                partTimeStaff++;
            }
        }
        return sum / partTimeStaff;
    }
    /**
     * Finds and returns the most absent FullTimeStaff member based on sick days remaining.
     *
     * @return The most absent FullTimeStaff, or null if there is no full time staff member.
     */
    public FullTimeStaff mostAbsentFullTime() {
        
        FullTimeStaff mostAbsent = null;
        for (int i = 0; i < staffList.length; i++) {
            Employee employee = staffList[i];
            if (employee instanceof FullTimeStaff staff && 
                    (mostAbsent == null || staff.compareToSickDays(mostAbsent) < 0)) { 
                // less sick days remaining = more absent
                mostAbsent = staff;
            }
        }
        return mostAbsent; // returns null if no full time staff
    }
    /**
     * Finds and returns the most absent PartTimeStaff member based on sick days used.
     *
     * @return The most absent PartTimeStaff, or null if there is no full time staff member.
     */
    public PartTimeStaff mostAbsentPartTime() {

        PartTimeStaff mostAbsent = null;
        for (int i = 0; i < staffList.length; i++) {
            Employee employee = staffList[i];
            if (employee instanceof PartTimeStaff staff &&
                    (mostAbsent == null || staff.compareToSickDays(mostAbsent) > 0)) {
                // more sick days used = more absent
                mostAbsent = staff;
            }
        }
        return mostAbsent;
    }
    /**
     * Resets the sick days for all FullTimeStaff members in the staff list.
     */
    public void yearlySickDayReset() {
        for (int i = 0; i < staffList.length; i++) {
            if (staffList[i] instanceof FullTimeStaff staff) {
                staff.resetSickDays();
            }
        }
    }
    /**
     * Resets the sick days for all PartTimeStaff members in the staff list.
     */
    public void monthlySickDayReset() {
        for (int i = 0; i < staffList.length; i++) {
            if (staffList[i] instanceof PartTimeStaff staff) {
                staff.resetSickDays();
            }
        }
    }
    /**
     * Finds the index of the staff member with the specified employee number in the staff list.
     *
     * @param employeeNumber The employee number to search for.
     * @return The index of the staff member if found; otherwise, returns -1.
     */
    private int indexOfEmployeeNumber(String employeeNumber) {
        for (int i = 0; i < staffList.length; i++) {
            if (staffList[i].getEmployeeNumber().equals(employeeNumber)) {
                return i;
            }
        }
        return -1;
    }
}
