/**
 * ICS4U <br>
 * Stanley Gu <br>
 * 11/28/23 <br>
 * Employee.java <br>
 * 
 * This is an abstract class representing an Employee.
 * Subclasses are expected to provide implementations for the abstract methods.
 */
public abstract class Employee {
    /**
     * Instance fields
     */
    private String employeeNumber;
    private String firstName;
    private String lastName;
    /**
     * Constructs an Employee with the specified information.
     *
     * @param employeeNumber The unique identification number of the employee.
     * @param firstName      The first name of the employee.
     * @param lastName       The last name of the employee.
     */
    public Employee(String employeeNumber, String firstName, String lastName) {
        this.employeeNumber = employeeNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }
    /**
     * Gets the employee's unique identification number.
     *
     * @return The employee's identification number.
     */
    public String getEmployeeNumber() {
        return employeeNumber;
    }
    /**
     * Calculates the pay for the employee. Subclasses must implement this method.
     *
     * @return The calculated pay for the employee.
     */
    public abstract double pay();
    /**
     * Deducts a specified number of sick days from the employee's record.
     *
     * @param sickDays The number of sick days to be deducted.
     */
    public abstract void deductSickDays(double sickDays);
    /**
     * Resets the sick day count for the employee.
     */
    public abstract void resetSickDays();
    /**
     * Prints a pay stub for the employee.
     */
    public void printPayStub() {
        System.out.printf("Employee Number: %s%n", employeeNumber);
    }
    /**
     * Returns a string representation of the Employee, including employee details.
     *
     * @return A string representation of the Employee.
     */
    public String toString() {
        return String.format("""
                \tEmployee Number: %s
                \tFirst Name: %s
                \tLast Name: %s
                """, employeeNumber, firstName, lastName);
    }
    /**
     * Converts the employee information to a string for data storage.
     *
     * @return A string representation of the employee's data.
     */
    public String toData() {
        return employeeNumber + '\n' + firstName + '\n' + lastName + '\n';
    }
}
