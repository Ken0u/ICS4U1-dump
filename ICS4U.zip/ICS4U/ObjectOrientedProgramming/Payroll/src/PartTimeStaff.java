/**
 * ICS4U <br>
 * Stanley Gu <br>
 * 11/28/23 <br>
 * PartTimeStaff.java <br>
 *
 * This class represents a part-time staff member, extending the abstract class Employee.
 * Part-time staff members are paid based on the number of hours worked at an hourly rate.
 */
public class PartTimeStaff extends Employee {
    /**
     * Class fields
     */
    public static final String TITLE = "Part-Time";
    private static final int HOURS_PER_DAY = 8;
    /**
     * Instance fields
     */
    private double numHoursAssigned;
    private double hourlyRate;
    private double sickDaysTaken;
    /**
     * Constructs a PartTimeStaff object with the specified information.
     *
     * @param employeeNumber  The unique identification number of the part-time staff member.
     * @param firstName       The first name of the part-time staff member.
     * @param lastName        The last name of the part-time staff member.
     * @param numHoursAssigned The number of hours assigned to the part-time staff member.
     * @param hourlyRate      The hourly rate for the part-time staff member.
     * @param sickDaysTaken    The number of sick days taken by the part-time staff member.
     */
    public PartTimeStaff(String employeeNumber, String firstName, String lastName,
                         double numHoursAssigned, double hourlyRate, double sickDaysTaken) {
        super(employeeNumber, firstName, lastName);
        this.numHoursAssigned = numHoursAssigned;
        this.hourlyRate = hourlyRate;
        this.sickDaysTaken = sickDaysTaken;
    }
    /**
     * Gets the hourly rate for the part-time staff member.
     *
     * @return The hourly rate.
     */
    public double getHourlyRate() {
        return hourlyRate;
    }
    /**
     * Calculates the total hours worked by subtracting sick days from the assigned hours.
     *
     * @return The total hours worked.
     */
    private double hoursWorked() {
        return numHoursAssigned - sickDaysTaken * HOURS_PER_DAY;
    }
    /**
     * Calculates the pay for the part-time staff member based on hours worked and hourly rate.
     *
     * @return The calculated pay.
     */
    @Override
    public double pay() {
        return hoursWorked() * hourlyRate;
    }
    /**
     * Deducts a specified number of sick days from the part-time staff member's record.
     *
     * @param sickDays The number of sick days to be deducted.
     */
    @Override
    public void deductSickDays(double sickDays) {
        sickDaysTaken += sickDays;
    }
    /**
     * Resets the sick day count for the part-time staff member.
     */
    @Override
    public void resetSickDays() {
        sickDaysTaken = 0;
    }
    /**
     * Prints a pay stub for the part-time staff member, including hours worked and amount earned.
     */
    @Override
    public void printPayStub() {
        super.printPayStub();
        System.out.printf("""
               \t# Of Hours Worked: %.2fh
               \tAmount Earned: $%.2f
               """, hoursWorked(), pay());
    }
    /**
     * Compares the number of sick days taken by this part-time staff member to another.
     * {@code other} cannot be null.
     *
     * @param other The other part-time staff member for comparison. 
     * @return The difference in sick days taken.
     */
    public double compareToSickDays(PartTimeStaff other) {
        return sickDaysTaken - other.sickDaysTaken; 
    }
    /**
     * Returns a string representation of the PartTimeStaff, including part-time specific details.
     *
     * @return A string representation of the PartTimeStaff.
     */
    @Override
    public String toString() {
        return String.format("\tTitle: %s\n", TITLE) + super.toString() + String.format("""
                \tHours Assigned: %.2fh
                \tHourly Rate: $%.2f/hr
                \tSick Days Taken: %.1f""", numHoursAssigned, hourlyRate, sickDaysTaken);
    }
    /**
     * Converts the part-time staff member information to a string for data storage.
     *
     * @return A string representation of the part-time staff member's data.
     */
    @Override
    public String toData() {
        return TITLE + '\n' + super.toData() + numHoursAssigned + '\n' + hourlyRate + '\n' + sickDaysTaken;
    }
    
}
