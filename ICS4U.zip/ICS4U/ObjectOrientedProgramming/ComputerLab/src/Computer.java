/**
 * Stanley Gu <br>
 * ICS4U <br>
 * 2023-11-14 <br>
 * Computer.java <br>
 * <br>
 * Represents a computer with various attributes such as serial number, manufacturer, and specifications.
 */
public class Computer {
    /**
     * Class fields
     */
    private static final int CURRENT_YEAR = 2023;
    /**
     * Instance fields
     */
    private String serialNumber;
    private String manufacturer;
    private int yearMade;
    private int yearPurchased;
    private double processorSpeed; // GHz
    private double ramSize; // GB
    private int warrantyExpiryYear;
    /**
     * Constructs a new Computer object with the specified parameters.
     *
     * @param serialNumber       The serial number of the computer.
     * @param manufacturer       The manufacturer of the computer.
     * @param yearMade           The year the computer was manufactured.
     * @param yearPurchased      The year the computer was purchased.
     * @param processorSpeed     The processor speed of the computer in gigahertz (GHz).
     * @param ramSize            The RAM size of the computer in gigabytes (GB).
     * @param warrantyExpiryYear The year when the warranty for the computer expires.
     */
    public Computer(String serialNumber, String manufacturer, int yearMade, int yearPurchased,
                    double processorSpeed, double ramSize, int warrantyExpiryYear) {
        this.serialNumber = serialNumber;
        this.manufacturer = manufacturer;
        this.yearMade = yearMade;
        this.yearPurchased = yearPurchased;
        this.processorSpeed = processorSpeed;
        this.ramSize = ramSize;
        this.warrantyExpiryYear = warrantyExpiryYear;
        
    }
    /**
     * Gets the serial number of the computer.
     *
     * @return The serial number.
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * Gets the manufacturer of the computer.
     *
     * @return The manufacturer.
     */
    public String getManufacturer() {
        return manufacturer;
    }

    /**
     * Gets the year the computer was manufactured.
     *
     * @return The manufacturing year.
     */
    public int getYearMade() {
        return yearMade;
    }

    /**
     * Gets the year the computer was purchased.
     *
     * @return The purchase year.
     */
    public int getYearPurchased() {
        return yearPurchased;
    }

    /**
     * Gets the processor speed of the computer.
     *
     * @return The processor speed in gigahertz (GHz).
     */
    public double getProcessorSpeed() {
        return processorSpeed;
    }

    /**
     * Gets the RAM size of the computer.
     *
     * @return The RAM size in gigabytes (GB).
     */
    public double getRamSize() {
        return ramSize;
    }

    /**
     * Gets the year when the warranty for the computer expires.
     *
     * @return The warranty expiry year.
     */
    public int getWarrantyExpiryYear() {
        return warrantyExpiryYear;
    }

    /**
     * Sets the serial number of the computer.
     *
     * @param serialNumber The new serial number to set.
     */
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    /**
     * Sets the manufacturer of the computer.
     *
     * @param manufacturer The new manufacturer to set.
     */
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    /**
     * Sets the year the computer was manufactured.
     *
     * @param yearMade The new manufacturing year to set.
     */
    public void setYearMade(int yearMade) {
        this.yearMade = yearMade;
    }

    /**
     * Sets the year the computer was purchased.
     *
     * @param yearPurchased The new purchase year to set.
     */
    public void setYearPurchased(int yearPurchased) {
        this.yearPurchased = yearPurchased;
    }

    /**
     * Sets the processor speed of the computer.
     *
     * @param processorSpeed The new processor speed to set in gigahertz (GHz).
     */
    public void setProcessorSpeed(double processorSpeed) {
        this.processorSpeed = processorSpeed;
    }

    /**
     * Sets the RAM size of the computer.
     *
     * @param ramSize The new RAM size to set in gigabytes (GB).
     */
    public void setRamSize(double ramSize) {
        this.ramSize = ramSize;
    }

    /**
     * Sets the year when the warranty for the computer expires.
     *
     * @param warrantyExpiryYear The new warranty expiry year to set.
     */
    public void setWarrantyExpiryYear(int warrantyExpiryYear) {
        this.warrantyExpiryYear = warrantyExpiryYear;
    }

    /**
     * Calculates the age of the computer by subtracting the manufacturing year
     * from the purchase year.
     *
     * @return The age of the computer in years.
     */
    public int age() {
        return CURRENT_YEAR - yearMade;
    }

    /**
     * Compares the processor speed of this computer with another computer.
     *
     * @param other The other computer to compare to.
     * @return A positive value if this computer has a higher processor speed,
     *         a negative value if it has a lower processor speed,
     *         and zero if the processor speeds are equal.
     */
    public double compareToProcessorSpeed(Computer other) {
        return processorSpeed - other.processorSpeed;
    }

    /**
     * Compares the RAM size of this computer with another computer.
     *
     * @param other The other computer to compare to.
     * @return A positive value if this computer has more RAM,
     *         a negative value if it has less RAM,
     *         and zero if the RAM sizes are equal.
     */
    public double compareToRamSize(Computer other) {
        return ramSize - other.ramSize;
    }

    /**
     * Compares the age of this computer with another computer.
     *
     * @param other The other computer to compare to.
     * @return A positive value if this computer is older, a negative value if it is younger, and zero if the ages are equal.
     */
    public int compareToAge(Computer other) {
        return age() - other.age();
    }

    /**
     * Returns a string representation of the computer.
     *
     * @return A formatted string containing the computer's details.
     */
    @Override
    public String toString() {
        return String.format("""
                Serial Number: %s
                Manufacturer: %s
                Year Made: %d
                Year Purchased: %d
                Processor Speed: %.2fGHz
                RAM: %.2fGB
                Warranty Expiry Year: %d""", serialNumber, manufacturer, yearMade, yearPurchased, processorSpeed, ramSize, warrantyExpiryYear);
    }
}
