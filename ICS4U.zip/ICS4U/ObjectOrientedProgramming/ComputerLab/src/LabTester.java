import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 * Stanley Gu <br>
 * ICS4U <br>
 * 2023-11-14 <br>
 * LabTester.java <br>
 * <br>
 * Tests the Computer and Lab classes.
 */
public class LabTester {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int maximumCapacity;
        Lab lab;
        
        System.out.print("Enter the maximum capacity of the lab: ");
        maximumCapacity = sc.nextInt();
        sc.nextLine();
        lab = new Lab(maximumCapacity);
        
        try {
            BufferedReader br = new BufferedReader(new FileReader("computer.txt"));
            int computers = Integer.parseInt(br.readLine());
            String serialNumber, manufacturer;
            int yearMade, yearPurchased, warrantyExpiryYear;
            double processorSpeed, ramSize;
            
            for (int i = 0; i < computers; i++) {
                serialNumber = br.readLine();
                manufacturer = br.readLine();
                yearMade = Integer.parseInt(br.readLine());
                yearPurchased = Integer.parseInt(br.readLine());
                processorSpeed = Double.parseDouble(br.readLine());
                ramSize = Double.parseDouble(br.readLine());
                warrantyExpiryYear = Integer.parseInt(br.readLine());
                
                lab.installComputer(serialNumber, manufacturer, yearMade, yearPurchased, processorSpeed, ramSize, warrantyExpiryYear);
            }
            br.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
        }

        double averageAge;
        Computer newest, fastest, largestRam;
        String manufacturer;
        int manufacturerCount;
        Computer[] expiring;
        
        averageAge = lab.averageAgeOfComputers();
        System.out.printf("Average Age: %.2f years%n", averageAge);
        System.out.println();
        
        newest = lab.newestComputer();
        System.out.printf("Newest Computer: %n%s%n", newest);
        System.out.println();
        
        fastest = lab.fastestComputer();
        largestRam = lab.computerWithLargestRam();
        System.out.printf("Fastest Computer: %n%s%n", lab.fastestComputer());
        if (fastest == largestRam) {
            System.out.println("The fastest computer has the largest RAM.");
        } else {
            System.out.println("The fastest computer does not have the largest RAM.");
        }
        System.out.println();
        
        System.out.print("Enter manufacturer name: ");
        manufacturer = sc.nextLine();
        manufacturerCount = lab.countComputersByManufacturer(manufacturer);
        System.out.printf("There are %d computers with the manufacturer %s.%n", manufacturerCount, manufacturer);
        System.out.println();
        
        expiring = lab.computersExpiringNextYear();
        System.out.println("Serial numbers of computers expiring next year: ");
        for (int i = 0; i < expiring.length; i++) {
            System.out.print(expiring[i].getSerialNumber() + " ");
        }
    }
}