/**
 * Stanley Gu <br>
 * ICS4U <br>
 * 2023-11-14 <br>
 * Lab.java <br>
 * <br>
 * The Lab class represents a computer laboratory with a specified maximum capacity.
 * It allows the installation of computers and provides various methods to analyze
 * and retrieve information about the installed computers.
 */
public class Lab {
    /**
     * Class fields
     */
    private static final int CURRENT_YEAR = 2023;
    /**
     * Instance fields
     */
    private int maximumCapacity;
    private int computersInstalled;
    private Computer[] computers;

    /**
     * Constructs a new Lab with the specified maximum capacity.
     *
     * @param maximumCapacity The maximum number of computers the lab can hold.
     */
    public Lab(int maximumCapacity) {
        this.maximumCapacity = maximumCapacity;
        computers = new Computer[maximumCapacity];
    }

    /**
     * Installs a new computer in the lab.
     *
     * @param serialNumber         The serial number of the computer.
     * @param manufacturer         The manufacturer of the computer.
     * @param yearMade             The manufacturing year of the computer.
     * @param yearPurchased        The year the computer was purchased.
     * @param processorSpeed       The processor speed of the computer.
     * @param ramSize              The RAM size of the computer.
     * @param warrantyExpiryYear   The warranty expiry year of the computer.
     * @return {@code true} if the computer was successfully installed, {@code false} if the lab is at maximum capacity.
     */
    public boolean installComputer(String serialNumber, String manufacturer, int yearMade, int yearPurchased,
                                   double processorSpeed, double ramSize, int warrantyExpiryYear) {
        if (computersInstalled == maximumCapacity) {
            return false;
        }
        
        Computer toBeInstalled = new Computer(serialNumber, manufacturer, yearMade, yearPurchased, processorSpeed, ramSize, warrantyExpiryYear);
        computers[computersInstalled] = toBeInstalled;
        computersInstalled++;
        return true;
    }

    /**
     * Calculates the average age of all installed computers in the lab.
     *
     * @return The average age of the installed computers, or 0 if no computers are installed.
     */
    public double averageAgeOfComputers() {
        if (computersInstalled == 0) {
            return 0;
        }
        
        double average = 0;
        for (int i = 0; i < computersInstalled; i++) {
            average += computers[i].age();
        }
        
        return average / computersInstalled;
    }

    /**
     * Retrieves the newest computer among all installed computers.
     *
     * @return The newest computer in the lab.
     */
    public Computer newestComputer() {
        Computer newest = computers[0];
        
        for (int i = 0; i < computersInstalled; i++) {
            if (computers[i].compareToAge(newest) < 0) {
                newest = computers[i];
            }
        }
        
        return newest;
    }

    /**
     * Retrieves the fastest computer among all installed computers.
     *
     * @return The fastest computer in the lab.
     */
    public Computer fastestComputer(){ 
        Computer fastest = computers[0];
        
        for (int i = 0; i < computersInstalled; i++) {
            if (computers[i].compareToProcessorSpeed(fastest) > 0) {
                fastest = computers[i];
            }
        }
        
        return fastest;
    }

    /**
     * Retrieves the computer with the largest RAM size among all installed computers.
     *
     * @return The computer with the largest RAM size in the lab.
     */
    public Computer computerWithLargestRam() {
        Computer largest = computers[0];
        
        for (int i = 0; i < computersInstalled; i++) {
            if (computers[i].compareToRamSize(largest) > 0) {
                largest = computers[i];
            }
        }
        
        return largest;
    }

    /**
     * Counts the number of computers in the lab manufactured by a specified manufacturer.
     *
     * @param manufacturer The manufacturer to count computers for.
     * @return The number of computers manufactured by the specified manufacturer.
     */
    public int countComputersByManufacturer(String manufacturer) {
        int count = 0;
        
        for (int i = 0; i < computersInstalled; i++) {
            if (computers[i].getManufacturer().equals(manufacturer)) {
                count++;
            }
        }
        
        return count;
    }

    /**
     * Retrieves an array of computers whose warranty is expiring in the next year.
     *
     * @return An array of computers expiring in the next year.
     */
    public Computer[] computersExpiringNextYear() {
        final int nextYear = CURRENT_YEAR + 1;
        int count = 0;
        Computer[] expiringComputers;
        int expiringIndex = 0;
        
        for (int i = 0; i < computersInstalled; i++) {
            if (computers[i].getWarrantyExpiryYear() == nextYear) {
                count++;
            }
        }
        
        expiringComputers = new Computer[count];
        for (int i = 0; i < computersInstalled; i++) {
            if (computers[i].getWarrantyExpiryYear() == nextYear) {
                expiringComputers[expiringIndex] = computers[i];
                expiringIndex++;
            }
        }
        
        return expiringComputers;
    }
}
