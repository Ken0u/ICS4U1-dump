
/**
 * JackCard.java <br>
 * Stanley Gu <br>
 * ICS4U1 <br>
 * Represents a Jackson Café card.<br>
 */
public class JackCard {
    /**
     * Static fields
     */
    private static final double[] DISCOUNT_PERCENTS = {0.02, 0.03, 0.05}; // discount percents
    private static final double[] DISCOUNT_PERCENTS_THRESHOLDS = {100, 200, 500}; // amount required for each discount ($)
    private static final int DOLLARS_PER_POINT = 2;
    private static final int POINTS_PER_DOLLAR = 20;
    private static double maxBalance = 10_000; // default amount is 10k
    /**
     * Instance fields
     */
    private String name;
    private double balance;
    private double discountPercent;
    private int points;
    private String PIN;
    
    /**
     * Default constructor for JackCard, initializes with default values.
     */
    public JackCard() {
        this("default", 0, "1234");
    }
    /**
     * Constructor for JackCard with specified parameters.
     *
     * @param name   The name of the card-holder.
     * @param balance The initial balance on the card.
     * @param PIN    The personal identification number for the card.
     */
    public JackCard(String name, double balance, String PIN) {
        this.name = name;
        this.balance = balance;
        updateDiscountPercent();
        this.PIN = PIN;
    }
    /**
     * Gets the name of the card-holder.
     *
     * @return The name of the card-holder.
     */
    public String getName() {
        return name;
    }
    /**
     * Gets the current balance on the card.
     *
     * @return The current balance on the card.
     */
    public double getBalance() {
        return balance;
    }
    /**
     * Get the discount percentage applicable to this card.
     *
     * @return The discount percentage as a decimal (e.g., 0.05 for 5%).
     */
    public double getDiscountPercent() {
        return discountPercent;
    }
    /**
     * Get the number of points accumulated on the card.
     *
     * @return The number of points on the card.
     */
    public int getPoints() {
        return points;
    }
    /**
     * Get the PIN (Personal Identification Number) associated with the card.
     *
     * @return The PIN of the card.
     */
    public String getPIN() {
        return PIN;
    }
    /**
     * Get the maximum allowed balance for a JackCard.
     *
     * @return The maximum allowed balance.
     */
    public static double getMaxBalance() {
        return maxBalance;
    }
    /**
     * Set the name of the cardholder.
     *
     * @param name The new name of the cardholder.
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * Set the current balance on the card.
     *
     * @param balance The new balance to be set.
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }
    /**
     * Set the discount percentage for this card.
     *
     * @param discountPercent The new discount percentage as a decimal (e.g., 0.05 for 5%).
     */
    public void setDiscountPercent(double discountPercent) {
        this.discountPercent = discountPercent;
    }
    /**
     * Set the number of points on the card.
     *
     * @param points The new number of points to be set.
     */
    public void setPoints(int points) {
        this.points = points;
    }
    /**
     * Set the PIN (Personal Identification Number) for the card.
     *
     * @param PIN The new PIN to be set.
     */
    public void setPIN(String PIN) {
        this.PIN = PIN;
    }
    /**
     * Set the maximum allowed balance for all JackCard instances.
     *
     * @param maxBalance The new maximum allowed balance.
     */
    public static void setMaxBalance(double maxBalance) {
        JackCard.maxBalance = maxBalance;
    }
    /**
     * Updates the discount percentage based on the current balance thresholds.
     * The discount percentage is adjusted depending on the balance held on the card.
     */
    private void updateDiscountPercent() {
        if (balance >= DISCOUNT_PERCENTS_THRESHOLDS[2]) {
            discountPercent = DISCOUNT_PERCENTS[2];
        } else if (balance >= DISCOUNT_PERCENTS_THRESHOLDS[1]) {
            discountPercent =  DISCOUNT_PERCENTS[1];
        } else if (balance >= DISCOUNT_PERCENTS_THRESHOLDS[0] ){
            discountPercent =  DISCOUNT_PERCENTS[0];
        } else {
            discountPercent = 0;
        }
    }

    /**
     * Refills the card with a specified amount.
     *
     * @param amount The amount to be refilled.
     * @return True if the refill is successful, false otherwise.
     */
    public boolean refill(double amount) {
        if (balance + amount > maxBalance) {
            balance = maxBalance;
            updateDiscountPercent();
            return false;
        } else {
            balance += amount;
            updateDiscountPercent();
            return true;
        }
    }
    /**
     * Pays for a purchase using the card.
     *
     * @param amount     The amount to be paid.
     * @param PIN        The personal identification number for the transaction validation.
     * @param usePoints  Boolean indicating if points should be redeemed for the purchase.
     * @return True if the purchase is successful, false otherwise.
     */
    public boolean pay(double amount, String PIN, boolean usePoints) {
        if (!PIN.equals(this.PIN)) {
            return false;
        }

        double amountPayed = amount;
        int pointsSpent = 0;
        if (usePoints) {
            int amountWithPoints = points / POINTS_PER_DOLLAR;
            int amountSpentWithPoints = (int) Math.min(amountPayed, amountWithPoints); // prevents spending more points than cost
            pointsSpent = amountSpentWithPoints * POINTS_PER_DOLLAR;
            
            amountPayed -= amountSpentWithPoints;
        }
        
        amountPayed *= 1 - discountPercent;
        if (balance >= amountPayed) {
            balance -= amountPayed;
            points -= pointsSpent; // if not using points will subtract 0
            
            points += (int) (amount / DOLLARS_PER_POINT);    
            updateDiscountPercent();
            return true;
        }
        
        return false;
    }
    /**
     * Compares the balance of this card with another card and returns the one with the higher balance.
     *
     * @param other The other JackCard to compare balances.
     * @return The JackCard with the higher balance.
     */
    public JackCard higherBalance(JackCard other) {
        if (balance > other.balance) {
            return this;
        }
        return other;
    }

    /**
     * Compares the points of this card with another card and returns the one with more points.
     *
     * @param other The other JackCard to compare points.
     * @return The JackCard with more points.
     */
    public JackCard morePoints(JackCard other) {
        if (points > other.points) {
            return this;
        }
        return other;
    }
    /**
     * Combines the points of this card with another card.
     *
     * @param other The other JackCard to combine points with.
     */
    public void combinePoints(JackCard other) {
        points += other.points;
        other.points = 0;
    }
    /**
     * Changes the PIN of the card if the name matches.
     *
     * @param name   The name of the card-holder.
     * @param newPIN The new PIN to be set.
     * @return True if PIN change is successful, false otherwise.
     */
    public boolean changePIN(String name, String newPIN) {
        if (name.equals(this.name)) {
            PIN = newPIN;
            return true;
        }
        return false;
    }

    /**
     * Provides a string representation of the card's details.
     *
     * @return A formatted string with cardholder's name, balance, discount rate, points, and PIN.
     */
    @Override
    public String toString() {
        return String.format("""
               Card Holder: %s
               Balance: $%.2f
               Discount rate: %.0f%%
               Points: %d
               PIN: %s
               """, name, balance, discountPercent * 100, points, PIN);
    }
    
}
