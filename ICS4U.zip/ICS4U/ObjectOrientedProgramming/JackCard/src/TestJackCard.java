import java.util.Scanner;

/**
 * TestJackCard.java <br>
 * Stanley Gu <br>
 * ICS4U1 <br>
 * Tests the JackCard class. <br>
 */
public class TestJackCard {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        
        // a)
        JackCard c1 = new JackCard();
        JackCard c2 = new JackCard("Bobby", 100, "3443");
        System.out.println(c1);
        System.out.println(c2);
        
        // b)
        System.out.print("Enter the max balance for a card: ");
        double maxBalance = sc.nextDouble();
        JackCard.setMaxBalance(maxBalance);
        sc.nextLine();
        
        // c)
        c1.refill(50);
        System.out.println(c1);
        System.out.println(c2);
        
        // d)
        c2.pay(60, "3443", false);
        System.out.println(c1);
        System.out.println(c2);
        
        // e)
        JackCard higherBalance = c1.higherBalance(c2);
        if (higherBalance == c1) {
            c1.pay(10, "1234", false);
        } else {
            c2.pay(10, "3443", false);
        }
        System.out.println(c1);
        System.out.println(c2);
        
        // f) 
        JackCard higherPoints = c1.morePoints(c2);
        if (higherPoints == c1) {
            c1.pay(5, "1234", true);
        } else {
            c2.pay(5, "3443", true);
        }
        System.out.println(c1);
        System.out.println(c2);
        
        // g)
        c1.combinePoints(c2);
        System.out.println(c1);
        System.out.println(c2);
        
        // h)
        c1.pay(5, "1234", true);
        System.out.println(c1);
        System.out.println(c2);
        
        //  i. Change the PIN for c1. Prompt user for the cardholder name and the new PIN.
        System.out.print("Enter cardholder name: ");
        String cardHolder = sc.nextLine();
        System.out.print("Enter new PIN: ");
        String newPIN = sc.nextLine();
        if (c1.changePIN(cardHolder, newPIN)) {
            System.out.println("Success");
        } else {
            System.out.println("Failed");
        }
        System.out.println(c1);
        System.out.println(c2);
        
    }
}