public class Main {
    public static void main(String[] args) {
        Book book = new Book("a", "a");
        Book history = new History("a", "b", "c");
        History history2 = new History("c", "b", "a");
        
        System.out.println(book);
        System.out.println(history);
        System.out.println(history2);   
    }
}