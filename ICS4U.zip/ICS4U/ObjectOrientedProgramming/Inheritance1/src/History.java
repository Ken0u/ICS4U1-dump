public class History extends Book{
    private String timePeriod;
    
    public History(String title, String author, String timePeriod) {
        super(title, author);
        this.timePeriod = timePeriod;
    }
    
    public String toString() {
        return super.toString() + "\n" +
                "Time Period: " + timePeriod;
    }
}
