public class TestCircle {
    
    /*
    a. Create two Circle objects c1, representing the circle with centre 
    (4, -1) and radius 3, and c2, representing the circle with centre (3, -2)
    and radius 5.
    b. Find and print the area of c1.
    c. Determine the smallest of c1 and c2 and then print its centre and
    radius.
    d. Determine whether c2 lies entirely within c1 and print an appropriate
    statement.
    e. Create a new reference, c3, to c1
    f. Create a new Circle object c4, with the same centre and radius as
    c1.
     */
    public static void main(String[] args) {
        // a)
        Circle c1 = new Circle(4, -1, 3);
        Circle c2 = new Circle(3, -2, 5);
        
        // b)
        System.out.println("c1 area = " + c1.area());
        
        // c)
        Circle smaller = c1.smaller(c2);
        System.out.println("Smaller is - " + smaller);
        
        // d)
        if (c2.isInside(c1)) {
            System.out.println("c2 is inside c1");
        } else {
            System.out.println("c2 is not inside c1");
        }
        
        // e)
        Circle c3 = c1;
        System.out.println("c3 - " + c3);
        
        // f)
        Circle c4 = new Circle(c1);
        System.out.println("c4 - " + c4);
        
        /*
        c1 == c3 : true
        c1 == c4 : false (created new object using fields from c1 only)
        c1.equals(c4) : true (fields are the same)
         */
    }
}