/**
 * Represents a circle
 */
public class Circle {
    private int x;
    private int y;
    private int radius;

    /**
     * Constructs a default circle object that lies on the origin with radius 1
     */
    public Circle() {
        this(0, 0, 1);
    }

    /**
     * Constructs a new circle object given the x-coordinate, y-coordinate and radius
     * @param x The x-coordinate of the center of the circle
     * @param y The y-coordinate of the center of the circle
     * @param radius The radius of the circle
     */
    public Circle(int x, int y, int radius) {
        this.x = x;
        this.y = y;
        this.radius = Math.abs(radius);
    }

    /**
     * Constructs a new circle object using the properties of another circle object. 
     * @param other The other circle object to copy
     */
    public Circle(Circle other) {
        x = other.x;
        y = other.y;
        radius = other.radius;
    }

    /**
     * @return The x coordinate at the center of the circle.
     */
    public int getX() {
        return x;
    }

    /**
     * @return The y coordinate at the center of the circle.
     */
    public int getY() {
        return y;
    }

    /**
     * @return The radius of the circle.
     */
    public int getRadius() {
        return radius;
    }

    /**
     * Sets the x coordinate for the center of the circle.
     * @param x The new x coordinate
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * Sets the y coordinate for the center of the circle.
     * @param y The new y coordinate
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * Sets the radius for the circle.
     * @param radius The new radius 
     */
    public void setRadius(int radius) {
        this.radius = radius;
    }

    /**
     * Calculates the area of the circle.
     * @return The area of the circle
     */
    public double area() {
        return Math.PI * radius * radius;
    }

    /**
     * Compares this circle's radius to another circle's radius and determines which one is smaller
     * @param other The other circle
     * @return A pointer to the smaller circle
     */
    public Circle smaller(Circle other) {
        if (radius < other.radius) {
            return this;
        }
        return other;
    }

    /**
     * Calculates the distance between the center of this circle and the center of another circle.
     * @param other The other circle
     * @return The distance between the two circles
     */
    public double distance(Circle other) {
        return Math.sqrt(Math.pow(other.x - x, 2) + Math.pow(other.y - y, 2));
    }

    /**
     * Checks if this circle is inside another circle. 
     * @param other The other circle
     * @return If this circle lies within another circle
     */
    public boolean isInside(Circle other) {
        return distance(other) + radius < other.radius;
    }

    /**
     * Checks if this circle's x-coordinate, y-coordinate and radius are equal to another circle's
     * and if the explicit circle object is not null.
     * @param other The other circle to compare
     * @return If the circle's x-coordinate, y-coordinate and radius are the same
     */
    public boolean equals(Circle other) {
        return other != null && x == other.x && y == other.y && radius == other.radius;
    }

    /**
     * Returns a string representation of the object
     * @return A string representing the object
     */
    @Override
    public String toString() {
        return String.format("center: (%d, %d) radius: %d", x, y, radius);
    }
}
