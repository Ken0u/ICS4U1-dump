/**
 * Stanley Gu <br>
 * ICS4U <br>
 * 12/02/23 <br>
 * PrimarySpec.java <br>
 *
 * The {@code PrimarySpec} class represents the primary specifications of a real estate property,
 * including zone code, price, size, and the number of bedrooms.
 */
public class PrimarySpec {
    /**
     * Instance fields
     */
    private String zoneCode;
    private double price;
    private double size;
    private int numBedRoom;

    /**
     * Constructs a new {@code PrimarySpec} with the specified zone code, price, size, and number of bedrooms.
     *
     * @param zoneCode   The zone code of the property.
     * @param price      The price of the property.
     * @param size       The size of the property.
     * @param numBedRoom The number of bedrooms in the property.
     */
    public PrimarySpec(String zoneCode, double price, double size, int numBedRoom) {
        this.zoneCode = zoneCode;
        this.price = price;
        this.size = size;
        this.numBedRoom = numBedRoom;
    }

    /**
     * Gets the zone code of the property.
     *
     * @return The zone code of the property.
     */
    public String getZoneCode() {
        return zoneCode;
    }

    /**
     * Gets the price of the property.
     *
     * @return The price of the property.
     */
    public double getPrice() {
        return price;
    }

    /**
     * Compares the size of this primary specification to another primary specification.
     *
     * @param other The other primary specification to compare.
     * @return A positive value if this primary specification is larger, a negative value if the other primary specification is larger,
     * or 0 if they are equal in size.
     */
    public double compareToSize(PrimarySpec other) {
        return size - other.size;
    }

    /**
     * Checks if this primary specification matches another primary specification.
     *
     * @param other The other primary specification to match.
     * @return {@code true} if the specifications match, {@code false} otherwise.
     */
    public boolean matchSpec(PrimarySpec other) {
        return other != null && zoneCode.equals(other.zoneCode) && price <= other.price && 
                size >= other.size && numBedRoom >= other.numBedRoom;
    }

    /**
     * Returns a string representation of the primary specifications, including zone code, price, size, and the number of bedrooms.
     *
     * @return A string representation of the primary specifications.
     */
    public String toString() {
        return String.format("""
                \t\tZone code: %s
                \t\tPrice: $%.2f
                \t\tSize: %.2f sq ft
                \t\tBedrooms: %d""", zoneCode, price, size, numBedRoom);
    }
}
