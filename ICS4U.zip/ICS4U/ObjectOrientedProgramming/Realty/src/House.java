/**
 * Stanley Gu <br>
 * ICS4U <br>
 * 12/02/23 <br>
 * House.java <br>
 *
 * The {@code House} class represents a specific type of real estate property - a house.
 * It extends the {@code Property} class and includes house-specific specifications.
 */
public class House extends Property {
    /**
     * Class fields
     */
    public static final String TITLE = "house";
    /**
     * Constructs a new {@code House} with the specified ID, address, primary specifications, and house-specific specifications.
     *
     * @param id        The ID of the house.
     * @param address   The address of the house.
     * @param primSpec  The primary specifications of the house.
     * @param houseSpec The house-specific specifications of the house.
     */
    public House(String id, String address, PrimarySpec primSpec, HouseSpec houseSpec) {
        super(id, address, primSpec, houseSpec);
    }
}
