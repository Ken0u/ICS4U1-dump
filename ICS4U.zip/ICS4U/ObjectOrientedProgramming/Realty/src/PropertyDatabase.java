import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Stanley Gu <br>
 * ICS4U <br>
 * 12/02/23 <br>
 * PropertyDatabase.java <br>
 *
 *  The {@code PropertyDatabase} class represents a database of properties, such as houses and condominiums.
 *  It provides methods to initialize the database from a file, search for properties, list properties,
 *  and perform various property-related operations.
 */
public class PropertyDatabase {
    /**
     * Instance fields
     */
    private int numProperty;
    private Property[] list;

    /**
     * Constructs a new {@code PropertyDatabase} by reading property information from a file.
     *
     * @param fileName The name of the file containing property information.
     */
    public PropertyDatabase(String fileName) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            
            numProperty = Integer.parseInt(br.readLine());
            list = new Property[numProperty];
            
            for (int i = 0; i < numProperty; i++) {
                br.readLine();
                String title = br.readLine();
                String id = br.readLine();
                String address = br.readLine();
                String zoneCode = br.readLine();
                double price = Double.parseDouble(br.readLine());
                double size = Double.parseDouble(br.readLine());
                int numBedrooms = Integer.parseInt(br.readLine());
                boolean spec1 = br.readLine().equals("Y");
                boolean spec2 = br.readLine().equals("Y");
                boolean spec3 = br.readLine().equals("Y");
                boolean spec4 = br.readLine().equals("Y");
                boolean spec5 = br.readLine().equals("Y");
                
                if (title.equals(House.TITLE)) {
                    list[i] = new House(id, address, 
                            new PrimarySpec(zoneCode, price, size, numBedrooms),
                            new HouseSpec(spec1, spec2, spec3, spec4, spec5)
                    );
                } else if (title.equals(Condo.TITLE)) {
                    list[i] = new Condo(id, address,
                            new PrimarySpec(zoneCode, price, size, numBedrooms),
                            new CondoSpec(spec1, spec2, spec3, spec4, spec5)
                    );
                }
            }
            
            
            br.close();
        } catch (IOException e) {
            System.out.println("An error has occurred.");
        }
    }

    /**
     * Searches for a property with the given ID in the database.
     *
     * @param id The ID of the property to search for.
     * @return The property with the specified ID, or null if not found.
     */
    public Property searchById(String id) {
        for (int i = 0; i < numProperty; i++) {
            if (list[i].getId().equals(id)) {
                return list[i];
            }
        }
        return null;
    }

    /**
     * Prints details of all properties in the database.
     */
    public void listAllProperties() {
        System.out.println("Properties:");
        for (int i = 0; i < numProperty; i++) {
            Property property = list[i];
            printProperty(property);
        }
    }

    /**
     * Prints details of all condominiums in the database.
     */
    public void listAllCondominiums() {
        System.out.println("Condominiums: ");
        for (int i = 0; i < numProperty; i++) {
            Property property = list[i];
            if (property instanceof Condo){
                printProperty(property);
            }
        }
    }

    /**
     * Prints details of all houses in the database.
     */
    public void listAllHouses() {
        System.out.println("Houses: ");
        for (int i = 0; i < numProperty; i++) {
            Property property = list[i];
            if (property instanceof House){
                printProperty(property);
            }
        }
    }

    /**
     * Prints details of a property with the specified ID.
     *
     * @param id The ID of the property to print.
     */
    public void printPropertyById(String id) {
        Property property = searchById(id);
        if (property != null) {
            printProperty(property);
        } else {
            System.out.println("Property not found.");
        }
    }

    /**
     * Prints details of properties that match the specified criteria.
     *
     * @param primarySpec   The primary specifications to match.
     * @param secondarySpec The secondary specifications to match.
     * @param percent       The matching percentage threshold.
     */
    public void printAllMatch(PrimarySpec primarySpec, SecondarySpec secondarySpec, double percent) {
        System.out.println("Matching properties:");
        for (int i = 0; i < numProperty; i++) {
            Property property = list[i];
            if (property.matchProperty(primarySpec, secondarySpec, percent)) {
                printProperty(property);
                System.out.println();
            }
        }
    }

    /**
     * Calculates the average price of properties in a specific zone.
     *
     * @param zoneCode The zone code for which to calculate the average price.
     * @return The average price of properties in the specified zone.
     */
    public double averagePriceInZone(String zoneCode) {
        double average = 0;
        int count = 0;
        
        for (int i = 0; i < numProperty; i++) {
            PrimarySpec primarySpec = list[i].getPrimSpec();
            if (primarySpec.getZoneCode().equals(zoneCode)) {
                average += primarySpec.getPrice();
                count++;
            }
        }
        
        return average / count;
    }

    /**
     * Finds the largest condominium in the database.
     *
     * @return The largest condominium in the database.
     */
    public Condo largestCondo() {
        Condo largest = null;
        
        for (int i = 0; i < numProperty; i++) {
            Property property = list[i];
            if (property instanceof Condo) {
                Condo condo = (Condo) property;
                
                if (largest == null || condo.compareToSize(largest) > 0) {
                    largest = condo;
                }
            }
        }
        
        return largest;
    }

    /**
     * Prints the details of a given property, including its primary and secondary specifications.
     *
     * @param property The property to print.
     */
    public static void printProperty(Property property) {
        System.out.println(property);
        System.out.println("\tPrimary Specs:");
        System.out.println(property.getPrimSpec());
        System.out.println("\tSecondary Specs:");
        System.out.println(property.getSecSpec());
    }
}
