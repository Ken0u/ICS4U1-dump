/**
 * Stanley Gu <br>
 * ICS4U <br>
 * 12/02/23 <br>
 * SecondarySpec.java <br>
 *
 * The {@code SecondarySpec} abstract class represents secondary specifications of a real estate property,
 * such as additional features or characteristics.
 */
public abstract class SecondarySpec {
    /**
     * Checks if this secondary specification matches another secondary specification within a given percentage threshold.
     *
     * @param other   The other secondary specification to match.
     * @param percent The matching percentage threshold.
     * @return {@code true} if the specifications match within the given percentage threshold, {@code false} otherwise.
     */
    public abstract boolean matchSpec(SecondarySpec other, double percent);
}
