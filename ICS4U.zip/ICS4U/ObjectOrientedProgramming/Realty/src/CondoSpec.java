/**
 * Stanley Gu <br>
 * ICS4U <br>
 * 12/02/23 <br>
 * CondoSpec.java <br>
 *
 * The {@code CondoSpec} class represents secondary specifications specific to condominiums, such as features and characteristics.
 * It extends the abstract class {@code SecondarySpec} and provides methods for matching and displaying condo-specific specifications.
 */
public class CondoSpec extends SecondarySpec {
    /**
     * Class fields
     */
    private static final int NUM_SPEC = 5;
    /**
     * Instance fields
     */
    private boolean pool;
    private boolean exRoom;
    private boolean locker;
    private boolean hydroIncluded;
    private boolean cableIncluded;
    /**
     * Constructs a new {@code CondoSpec} with the specified condo-specific features.
     *
     * @param pool          Indicates whether the condo has a pool.
     * @param exRoom        Indicates whether the condo has an extra room.
     * @param locker        Indicates whether the condo has a locker.
     * @param hydroIncluded Indicates whether hydro is included in the condo.
     * @param cableIncluded Indicates whether cable is included in the condo.
     */
    public CondoSpec(boolean pool, boolean exRoom, boolean locker, boolean hydroIncluded, boolean cableIncluded) {
        this.pool = pool;
        this.exRoom = exRoom;
        this.locker = locker;
        this.hydroIncluded = hydroIncluded;
        this.cableIncluded = cableIncluded;
    }

    /**
     * Checks if this condo-specific specification matches another condo-specific specification within a given percentage threshold.
     *
     * @param other   The other condo-specific specification to match.
     * @param percent The matching percentage threshold.
     * @return {@code true} if the specifications match within the given percentage threshold, {@code false} otherwise.
     */
    @Override
    public boolean matchSpec(SecondarySpec other, double percent) {
        if (!(other instanceof CondoSpec)) {
            return false;
        }
        
        CondoSpec condoSpec = (CondoSpec) other;

        int matches = 0;
        if (pool == condoSpec.pool) {
             matches++;
        }
        if (exRoom == condoSpec.exRoom) {
            matches++;
        }
        if (locker == condoSpec.locker) {
            matches++;
        }
        if (hydroIncluded == condoSpec.hydroIncluded) {
            matches++;
        }
        if (cableIncluded == condoSpec.cableIncluded) {
            matches++;
        }
        
        return (double) matches / NUM_SPEC >= percent;
    }

    /**
     * Returns a string representation of the condo-specific specifications.
     *
     * @return A string representation of the condo-specific specifications.
     */
    public String toString() {
        return String.format("""
                \t\tPool: %b
                \t\tExtra room: %b
                \t\tLocker: %b
                \t\tHydro included: %b
                \t\tCable included: %b""", pool, exRoom, locker, hydroIncluded, cableIncluded);
    }
}
