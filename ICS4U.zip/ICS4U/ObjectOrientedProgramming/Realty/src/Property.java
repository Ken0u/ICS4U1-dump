/**
 * Stanley Gu <br>
 * ICS4U <br>
 * 12/02/23 <br>
 * Property.java <br>
 *
 *  The {@code Property} class represents a generic real estate property with an ID, address, primary specifications,
 *  and secondary specifications. It provides methods for accessing and comparing property information.
 */
public class Property {
    /**
     * Instance fields
     */
    private String id;
    private String address;
    private PrimarySpec primSpec;
    private SecondarySpec secSpec;

    /**
     * Constructs a new {@code Property} with the specified ID, address, primary specifications, and secondary specifications.
     *
     * @param id       The ID of the property.
     * @param address  The address of the property.
     * @param primSpec The primary specifications of the property.
     * @param secSpec  The secondary specifications of the property.
     */
    public Property(String id, String address, PrimarySpec primSpec, SecondarySpec secSpec) {
        this.id = id;
        this.address = address;
        this.primSpec = primSpec;
        this.secSpec = secSpec;
    }

    /**
     * Gets the primary specifications of the property.
     *
     * @return The primary specifications of the property.
     */
    public PrimarySpec getPrimSpec() {
        return primSpec;
    }

    /**
     * Gets the secondary specifications of the property.
     *
     * @return The secondary specifications of the property.
     */
    public SecondarySpec getSecSpec() {
        return secSpec;
    }

    /**
     * Gets the ID of the property.
     *
     * @return The ID of the property.
     */
    public String getId() {
        return id;
    }

    /**
     * Compares the size of this property to another property.
     *
     * @param other The other property to compare.
     * @return A positive value if this property is larger, a negative value if the other property is larger, or 0 if they are equal in size.
     */
    public double compareToSize(Property other) {
        return primSpec.compareToSize(other.primSpec);
    }

    /**
     * Checks if this property matches the specified primary and secondary specifications within the given percentage threshold.
     *
     * @param primarySpec   The primary specifications to match.
     * @param secondarySpec The secondary specifications to match.
     * @param percent       The matching percentage threshold.
     * @return {@code true} if the property matches the specifications, {@code false} otherwise.
     */
    public boolean matchProperty(PrimarySpec primarySpec, SecondarySpec secondarySpec, double percent) {
        return primSpec.matchSpec(primarySpec) && secSpec.matchSpec(secondarySpec, percent); 
    }

    /**
     * Returns a string representation of the property, including its ID and address.
     *
     * @return A string representation of the property.
     */
    public String toString() {
        return String.format("""
                ID: %s
                \tAddress: %s""", id, address);
    }
}
