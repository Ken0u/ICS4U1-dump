import java.util.Scanner;

/**
 * Stanley Gu <br>
 * ICS4U <br>
 * 12/02/23 <br>
 * Realty.java <br>
 *
 * Simulates a realty company through a database.
 */

public class Realty {
    public static void main(String[] args) {
        PropertyDatabase database = new PropertyDatabase("data.txt");
        Scanner sc = new Scanner(System.in);
        int choice;

        String menu = """
                Menu:
                1. Load properties from a file
                2. List all properties
                3. List all condominiums
                4. List all houses
                5. Search for a property by ID
                6. Search for properties by specifications
                7. Print average price of all properties in the specified zone
                8. Find the largest condo
                9. Exit
                Please enter your choice (1-9):\s""";

        System.out.print(menu);
        choice = sc.nextInt();

        while (choice != 9) {
            switch (choice) {
                case 1 -> System.out.println("Already loaded.");
                case 2 -> database.listAllProperties();
                case 3 -> database.listAllCondominiums();
                case 4 -> database.listAllHouses();
                case 5 -> {
                    sc.nextLine();
                    System.out.print("Enter the ID of a property to search for: ");
                    String id = sc.nextLine();
                    database.printPropertyById(id);
                }
                case 6 -> {
                    sc.nextLine();
                    System.out.print("House or Condo? ");
                    String title = sc.nextLine();

                    System.out.print("Enter the zone code: ");
                    String zoneCode = sc.nextLine();
                    System.out.print("Enter the price: ");
                    double price = Double.parseDouble(sc.nextLine());
                    System.out.print("Enter the size: ");
                    double size = Double.parseDouble(sc.nextLine());
                    System.out.print("Enter the number of bedrooms: ");
                    int numBedrooms = Integer.parseInt(sc.nextLine());

                    if (title.equalsIgnoreCase(House.TITLE)) {
                        System.out.print("Does it have a vacuum? (Y/N): ");
                        boolean vacuum = sc.nextLine().equalsIgnoreCase("Y");
                        System.out.print("Does it have an AC? (Y/N): ");
                        boolean ac = sc.nextLine().equalsIgnoreCase("Y");
                        System.out.print("Does it have a fireplace? (Y/N): ");
                        boolean fireplace = sc.nextLine().equalsIgnoreCase("Y");
                        System.out.print("Does it have hardwood floors? (Y/N): ");
                        boolean hardwood = sc.nextLine().equalsIgnoreCase("Y");
                        System.out.print("Does it have a basement? (Y/N): ");
                        boolean basement = sc.nextLine().equalsIgnoreCase("Y");
                        System.out.print("Enter percent: ");
                        double percent = Double.parseDouble(sc.nextLine());
                        database.printAllMatch(new PrimarySpec(zoneCode, price, size, numBedrooms),
                                new HouseSpec(vacuum, ac, fireplace, hardwood, basement), percent / 100);
                    } else if (title.equalsIgnoreCase(Condo.TITLE)){
                        System.out.print("Does it have a pool? (Y/N): ");
                        boolean pool = sc.nextLine().equalsIgnoreCase("Y");
                        System.out.print("Does it have an exercise room? (Y/N): ");
                        boolean exRoom = sc.nextLine().equalsIgnoreCase("Y");
                        System.out.print("Does it have a locker? (Y/N): ");
                        boolean locker = sc.nextLine().equalsIgnoreCase("Y");
                        System.out.print("Is hydro included? (Y/N): ");
                        boolean hydroIncluded = sc.nextLine().equalsIgnoreCase("Y");
                        System.out.print("Is cable included? (Y/N): ");
                        boolean cableIncluded = sc.nextLine().equalsIgnoreCase("Y");
                        System.out.print("Enter percent: ");
                        double percent = Double.parseDouble(sc.nextLine());
                        database.printAllMatch(new PrimarySpec(zoneCode, price, size, numBedrooms),
                                new CondoSpec(pool, exRoom, locker, hydroIncluded, cableIncluded), percent / 100);
                    }
                }
                case 7 -> {
                    sc.nextLine();
                    System.out.print("Enter zone code: ");
                    String zoneCode = sc.nextLine();
                    double averagePrice = database.averagePriceInZone(zoneCode);
                    System.out.printf("The average price in that zone is: $%.2f\n",averagePrice);
                }
                case 8 -> {
                    Condo condo = database.largestCondo();
                    if (condo == null) {
                        System.out.println("There are no condos.");
                    } else {
                        PropertyDatabase.printProperty(condo);
                    }
                }
            }

            System.out.print(menu);
            choice = sc.nextInt();
        }

    }
}
