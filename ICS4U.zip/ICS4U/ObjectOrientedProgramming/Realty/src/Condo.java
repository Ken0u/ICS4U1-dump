public class Condo extends Property{
    public static final String TITLE = "condo";
    public Condo(String id, String address, PrimarySpec primSpec, CondoSpec condoSpec) {
        super(id, address, primSpec, condoSpec);
    }
}
