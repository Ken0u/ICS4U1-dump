/**
 * Stanley Gu <br>
 * ICS4U <br>
 * 12/02/23 <br>
 * HouseSpec.java <br>
 *
 * The {@code HouseSpec} class represents secondary specifications specific to houses, such as features and characteristics.
 * It extends the abstract class {@code SecondarySpec} and provides methods for matching and displaying house-specific specifications.
 */
public class HouseSpec extends SecondarySpec {
    /**
     * Class fields
     */
    private static final int NUM_SPEC = 5;
    /**
     * Instance fields
     */
    private boolean vacuum;
    private boolean ac;
    private boolean fireplace;
    private boolean hardwood;
    private boolean basement;
    public HouseSpec(boolean vacuum, boolean ac, boolean fireplace, boolean hardwood, boolean basement) {
        this.vacuum = vacuum;
        this.ac = ac;
        this.fireplace = fireplace;
        this.hardwood = hardwood;
        this.basement = basement;
    }

    /**
     * Checks if this house-specific specification matches another house-specific specification within a given percentage threshold.
     *
     * @param other   The other house-specific specification to match.
     * @param percent The matching percentage threshold.
     * @return {@code true} if the specifications match within the given percentage threshold, {@code false} otherwise.
     */
    @Override
    public boolean matchSpec(SecondarySpec other, double percent) {
        if (!(other instanceof HouseSpec)) {
            return false;
        }
        HouseSpec houseSpec = (HouseSpec) other;
        
        int matches = 0;
        if (vacuum == houseSpec.vacuum) {
            matches++;
        }
        if (ac == houseSpec.ac) {
            matches++;
        }
        if (fireplace == houseSpec.fireplace) {
            matches++;
        }
        if (hardwood == houseSpec.fireplace) {
            matches++;
        }
        if (basement == houseSpec.basement) {
            matches++;
        }
        return (double) matches / NUM_SPEC >= percent;
    }

    /**
     * Returns a string representation of the house-specific specifications.
     *
     * @return A string representation of the house-specific specifications.
     */
    @Override
    public String toString() {
        return String.format("""
                \t\tVacuum: %b
                \t\tAC: %b
                \t\tFireplace: %b
                \t\tHardwood: %b
                \t\tBasement: %b""", vacuum, ac, fireplace, hardwood, basement);
    }
}
