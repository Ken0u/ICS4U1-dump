import java.util.Scanner;

public class LockTracker {
    public static void main(String[] args) {
        final int LOCK_ONE_NUMBER = 1;
        final int LOCK_TWO_NUMBER = 2;
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter universal key: ");
        int universalKey = sc.nextInt();
        Lock.setUniversalKey(universalKey);
        
        Lock lock1;
        Lock lock2;
        System.out.print("Enter key for Lock #1: ");
        int key = sc.nextInt();
        while (!Lock.validKey(key)) {
            System.out.println("Invalid key.");
            System.out.print("Enter key for Lock #1: ");
            key = sc.nextInt();
        }
        lock1 = new Lock(key);
        
        System.out.print("Enter key for Lock #2: ");
        key = sc.nextInt();
        while (!Lock.validKey(key)) {
            System.out.println("Invalid Key.");
            System.out.print("Enter key for Lock #2: ");
            key = sc.nextInt();
        }
        lock2 = new Lock(key);
        
        System.out.print("Close lock #: ");
        int closeLock = sc.nextInt();
        while (closeLock == LOCK_ONE_NUMBER || closeLock == LOCK_TWO_NUMBER) {
            if (closeLock == LOCK_ONE_NUMBER) {
                lock1.close();
            } else if (closeLock == LOCK_TWO_NUMBER) {
                lock2.close();
            }
            System.out.print("Close lock #: ");
            closeLock = sc.nextInt();
        }
        
        System.out.println("Open lock #1: ");
        System.out.print("Enter key for lock #1: ");
        int guessKey = sc.nextInt();
        if (lock1.open(guessKey)) {
            System.out.println("Lock 1 opened.");
        } else {
            System.out.println("Lock 1 not opened.");
        }
        
        if (lock1.equals(lock2)) {
            System.out.println("The two locks have the same key.");
        } else {
            System.out.println("The two locks do not have the same key.");
        }
        
        int locksClosed = 0;
        if (!lock1.isOpen()) {
            locksClosed++;
        }
        if (!lock2.isOpen()) {
            locksClosed++;
        }
        System.out.println("Lock 1: " + lock1);
        System.out.println("Lock 2: " + lock2);
        System.out.println(locksClosed + " locks(s) is / are closed");
    }
}