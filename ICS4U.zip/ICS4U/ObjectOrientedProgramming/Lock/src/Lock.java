public class Lock {
    private int key;
    private boolean open;
    private int failAttempt;
    
    private static final int NUM_DIGIT = 6;
    private static final int MAX_FAIL_ATTEMPT = 3;
    private static int universalKey;
    
    public Lock(int key) {
        open = true;
        this.key = key;
        failAttempt = 0;
    }
    
    public static void setUniversalKey(int universalKey) {
        Lock.universalKey = universalKey;
    }
    public static boolean validKey(int key) {
        return ("" + key).length() == NUM_DIGIT;
    }
    public void close(){ 
        open = false;
    }
    public boolean isOpen(){
        return open;
    }
    
    public boolean open(int key) {
        if (open) {
            return true;
        }
        
        if (failAttempt <= MAX_FAIL_ATTEMPT) {
            if (key == this.key || key == universalKey) {
                open = true;
                failAttempt = 0;
                return true;
            } else {
                failAttempt++;
                return false;
            }
        } else {
            if (key == universalKey) {
                open = true;
                failAttempt = 0;
                return true;
            } else {
                System.out.println("ALARM");
                failAttempt++;
                return false;
            }
        }
    }
    
    public boolean equals(Lock other) {
        return other != null && this.key == other.key;
    }
    public String toString() {
        if (open) {
            return "open";
        } 
        return "closed";
    }
}
