public class Square {
    public static void main(String[] args) {
        System.out.println(square(1));
        System.out.println(square(3));
        System.out.println(square(6));
    }

    public static int square(int n) {
        if (n == 1) {
            return 1;
        }

        return square(n - 1) + 2 * n - 1;
    }
}
