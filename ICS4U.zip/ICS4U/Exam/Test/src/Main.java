public class Main {
    public static void main(String[] args) {
        guess("wyyzzabcawx", 'x');
    }
    public static void guess(String s, char c) {
        if (s.length() >= 2) {
            if (s.charAt(0) == s.charAt(1)) {
                System.out.println(c);
                guess(s.substring(2), c);
                System.out.println(s.substring(2));
            } else if (s.charAt(s.length() - 1) == c) {
                guess(s.substring(1, s.length() - 1), s.charAt(0));
                System.out.println(s);
            }
        }
    }
}