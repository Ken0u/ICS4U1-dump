import java.util.Scanner;

public class DigitSum {
    public static void main(String[] args) {
        int number, sum;
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter 3 digit number: ");
        number = sc.nextInt();

        sum = number % 10 + number / 10 % 10 + number / 100;
        System.out.printf("Sum of digits of the number %d is %d.", number, sum);
    }
}
