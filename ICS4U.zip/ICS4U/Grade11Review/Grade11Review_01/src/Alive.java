import java.util.Scanner;

public class Alive {
    public static void main(String[] args) {
        int birthYear, birthMonth, birthDate;
        int currentYear, currentMonth, currentDate;
        int daysAlive, hoursSlept;
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter your birthdate: ");
        System.out.print("Year: ");
        birthYear = sc.nextInt();
        System.out.print("Month: ");
        birthMonth = sc.nextInt();
        System.out.print("Day: ");
        birthDate = sc.nextInt();
        System.out.println("Enter today's date: ");
        System.out.print("Year: ");
        currentYear = sc.nextInt();
        System.out.print("Month: ");
        currentMonth = sc.nextInt();
        System.out.print("Day: ");
        currentDate = sc.nextInt();

        daysAlive = (currentYear - birthYear) * 365 + (currentMonth - birthMonth) * 30 + (currentDate - birthDate);
        hoursSlept = daysAlive * 8;
        System.out.printf("Days Alive: %d%n", daysAlive);
        System.out.printf("Hours Alive: %d%n", hoursSlept);
    }
}
