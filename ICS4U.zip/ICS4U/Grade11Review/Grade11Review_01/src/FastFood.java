import java.util.Scanner;

public class FastFood {
    public static void main(String[] args) {
        final double BURGER_COST = 1.69, FRIES_COST = 1.09, SODAS_COST = 0.99;
        final double PST = 0.08, GST = 0.05;
        int burgers, fries, sodas;
        double pst, gst, subtotal, total, tendered, change;
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of burgers: ");
        burgers = sc.nextInt();
        System.out.print("Enter number of fries: ");
        fries = sc.nextInt();
        System.out.print("Enter number of sodas: ");
        sodas = sc.nextInt();

        subtotal = burgers * BURGER_COST + fries + FRIES_COST + sodas * SODAS_COST;
        pst = subtotal * PST;
        gst = subtotal * GST;
        total = subtotal + pst + gst;

        System.out.printf("Subtotal: $%.2f%n", subtotal);
        System.out.printf("PST: $%.2f%n", pst);
        System.out.printf("GST: $%.2f%n", gst);
        System.out.printf("Total: $%.2f%n", total);

        System.out.print("Enter amount tendered: ");
        tendered = sc.nextDouble();
        change = tendered - total;

        System.out.printf("Change: $%.2f%n", change);

    }

}
