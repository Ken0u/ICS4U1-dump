import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CountCases {
    public static void main(String[] args) {
        int lowercase = 0, uppercase = 0;

        try {
            BufferedReader br = new BufferedReader(new FileReader("passage.txt"));

            String line = br.readLine();
            while (line != null) {
                for (int i = 0; i < line.length(); i++) {
                    char letter = line.charAt(i);
                    if (letter >= 'a' && letter <= 'z') {
                        lowercase++;
                    } else if (letter >= 'A' && letter <= 'Z') {
                        uppercase++;
                    }
                }

                line = br.readLine();
            }

            System.out.println("Lowercase letters: " + lowercase);
            System.out.println("Uppercase letters: " + uppercase);
        } catch (IOException e) {
            System.out.println("An IOException has occurred.");
        }
    }
}
