import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class TwoPowerTable {
    public static void main(String[] args) {
        int rows, number = 1;
        Scanner sc = new Scanner(System.in);

        rows = sc.nextInt();

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("twoPowerTable.html"));

            bw.write("""
                    <html><head>
                    <title>Powers of Two</title>
                    </head>
                    <body>
                    <table border cellpadding=5>
                    <tr><th>Power of 2</th><th>Value</th></tr>""");

            for (int i = 0; i < rows; i++) {
                bw.write(String.format("<tr><td>%d</td><td>%d</td></tr>", i, number));
                number *= 2;
            }

            bw.write("""
                    </table>
                    </body></html>""");

            bw.close();
        } catch (IOException e) {
            System.out.println("An IOException has occurred");
        }

    }
}