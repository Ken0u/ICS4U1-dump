import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class StarTable {
    public static void main(String[] args) {
        char[][] table;
        int rows, cols;
        Scanner sc = new Scanner(System.in);

        rows = sc.nextInt();
        cols = sc.nextInt();
        table = new char[rows][cols];

        for (int i = 0; i < rows; i++){
            for (int j = 0; j < cols; j++){
                table[i][j] = '*';
            }
        }

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("star.txt"));

            for (int i = 0; i < rows; i++){
                for (int j = 0; j < cols; j++){
                    bw.write(table[i][j]+ " ");
                }
                bw.newLine();
            }
            bw.close();
        } catch (IOException e) {
            System.out.println("An IOException has occurred");
        }


    }
}
