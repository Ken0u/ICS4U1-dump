import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Numbers {
    public static void main(String[] args) {
        double sum = 0;
        Scanner sc = new Scanner(System.in);

        try {
            BufferedReader br = new BufferedReader(new FileReader("numbers.txt"));
            String line;

            line = br.readLine();
            while (line != null) {
                sum += Double.parseDouble(line);
                line = br.readLine();
            }

            System.out.println("Sum is " + sum);
            br.close();
        } catch (IOException e) {
            System.out.println("An IOException has occurred.");
        }

    }
}
