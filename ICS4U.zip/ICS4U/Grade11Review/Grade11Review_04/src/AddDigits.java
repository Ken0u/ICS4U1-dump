import java.util.Scanner;

public class AddDigits {
    public static void main(String[] args) {
        String number;
        Scanner sc = new Scanner(System.in);
        int sum = 0;

        number = sc.nextLine();

        for (int i = 0; i < number.length(); i++){
            sum += number.charAt(i) - '0';
        }

        System.out.println(sum);
    }
}
