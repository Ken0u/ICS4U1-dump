import java.util.Scanner;

public class AddPairs {
    public static void main(String[] args) {
        String number;
        int sum = 0;
        Scanner sc = new Scanner(System.in);

        number = sc.nextLine();

        for (int i = 0; i <= number.length() - 2; i+=2) {
            sum += Integer.parseInt(number.substring(i, i + 2));
        }

        if (number.length() % 2 == 1) {
            sum += number.charAt(number.length() - 1) - '0';
        }

        System.out.println(sum);

    }
}
