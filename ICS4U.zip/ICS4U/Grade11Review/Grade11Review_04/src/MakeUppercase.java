import java.util.Scanner;

public class MakeUppercase {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String lowercase;

        lowercase = sc.nextLine();
        System.out.println(lowercase.toUpperCase());

    }
}