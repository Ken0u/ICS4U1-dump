import token.RedToken;
import token.Token;
import token.YellowToken;

public class Grid {
    private final Token[][] grid;

    public Grid(String[] grid) {
        int rows = grid.length;
        int cols = grid[0].length();

        this.grid = new Token[rows][cols];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                switch (grid[i].charAt(j)) {
                    case 'r' -> this.grid[i][j] = new RedToken();
                    case 'y' -> this.grid[i][j] = new YellowToken();
                    case 'e' -> this.grid[i][j] = null;
                }
            }
        }
    }

    public int getRows() {
        return grid.length;
    }

    public int getColumns() {
        return grid[0].length;
    }

    public Token tokenAt(int row, int col) {
        return grid[row][col];
    }
}
