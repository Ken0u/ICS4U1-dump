package token;

public class YellowToken extends Token{

    @Override
    public PlayerColor getColor() {
        return PlayerColor.YELLOW;
    }
}
