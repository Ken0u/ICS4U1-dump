package token;

public class RedToken extends Token {
    @Override
    public PlayerColor getColor() {
        return PlayerColor.RED;
    }
}
