package token;

public abstract class Token {
    public abstract PlayerColor getColor();
}
