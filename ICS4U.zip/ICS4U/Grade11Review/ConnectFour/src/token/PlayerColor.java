package token;

public enum PlayerColor {
    RED, YELLOW
}
