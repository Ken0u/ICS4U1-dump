import token.PlayerColor;
import token.Token;

//
public class Game {
    private Grid grid;

    public Game(Grid grid) {
        this.grid = grid;
    }

    public static void main(String[] args) {
        String[] startingGrid =
                {
                        "eeeeeee",
                        "eeereee",
                        "eyereee",
                        "eeyreee",
                        "eeryeee",
                        "eerryre",
                };

        Grid grid = new Grid(startingGrid);
        Game game = new Game(grid);

        PlayerColor color = game.getWinner();
        System.out.println(color);
    }


    private static final int[][] directions = {
            {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}, {-1, -1}
    };

    public static final int IN_A_ROW_WIN = 4;

    public PlayerColor getWinner() {
        boolean terminal = false;
        PlayerColor winner = null;

        for (int i = 0; i < grid.getRows() && !terminal; i++) {
            for (int j = 0; j < grid.getColumns() && !terminal; j++) {
                Token token = grid.tokenAt(i, j);
                if (token != null) {
                    for (int k = 0; k < directions.length; k++) {
                        if (getWinnerHelper(token.getColor(), k, 1, i, j)) {
                            winner = token.getColor();
                        }
                    }
                }
            }
        }

        return winner;
    }

    public boolean getWinnerHelper(PlayerColor color, int direction, int consecutive, int row, int column) {

        if (consecutive == IN_A_ROW_WIN) return true;

        int newRow = row + directions[direction][0];
        int newColumn = column + directions[direction][1];

        if (newRow < grid.getRows() && newRow >= 0 && newColumn < grid.getColumns() && newColumn >= 0 &&
                grid.tokenAt(newRow, newColumn) != null && grid.tokenAt(newRow, newColumn).getColor() == color) {
            return getWinnerHelper(color, direction, consecutive + 1, newRow, newColumn);
        }

        return false;
    }
}
