import java.util.Scanner;

public class CheckLine {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int l1v1x, l1v1y, l1v2x, l1v2y;
        int l2v1x, l2v1y, l2v2x, l2v2y;
        double line1Length, line2Length;
        double line1Slope, line2Slope;

        System.out.println("Please enter the two coordinates of line 1:");
        System.out.print("Vertex 1 x-value: ");
        l1v1x = sc.nextInt();
        System.out.print("Vertex 1 y-value: ");
        l1v1y = sc.nextInt();
        System.out.print("Vertex 2 x-value: ");
        l1v2x = sc.nextInt();
        System.out.print("Vertex 2 y-value: ");
        l1v2y = sc.nextInt();

        System.out.println("Please enter the two coordinates of line 2:");
        System.out.print("Vertex 1 x-value: ");
        l2v1x = sc.nextInt();
        System.out.print("Vertex 1 y-value: ");
        l2v1y = sc.nextInt();
        System.out.print("Vertex 2 x-value: ");
        l2v2x = sc.nextInt();
        System.out.print("Vertex 2 y-value: ");
        l2v2y = sc.nextInt();

        line1Length = Line.length(l1v1x, l1v1y, l1v2x, l1v2y);
        line2Length = Line.length(l2v1x, l2v1y, l2v2x, l2v2y);

        System.out.println("Result:");
        if (line1Length == line2Length) {
            System.out.println("The two lines have the same length.");
        } else {
            System.out.println("The two lines have different length.");
        }

        line1Slope = Line.slope(l1v1x, l1v1y, l1v2x, l1v2y);
        line2Slope = Line.slope(l2v1x, l2v1y, l2v2x, l2v2y);

        if (line1Slope == line2Slope) {
            System.out.println("The two lines are parallel.");
        } else if (line1Slope == -1 / line2Slope){
            System.out.println("The two lines are perpendicular.");
        }




    }
}
