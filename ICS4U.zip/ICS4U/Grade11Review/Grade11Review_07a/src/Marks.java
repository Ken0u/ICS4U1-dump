import java.io.*;
import java.util.Arrays;

public class Marks {
    public static void main(String[] args) {
        // a)
        final int STUDENTS = 10, TESTS = 5;
        double[][] marks = new double[STUDENTS][TESTS];
        double[] averages = new double[STUDENTS];

        // b)
        try {
            BufferedReader br = new BufferedReader(new FileReader("marks.txt"));

            for (int i = 0; i < STUDENTS; i++){
                String[] stringTests = br.readLine().split(" ");
                for (int j = 0; j < TESTS; j++) {
                    marks[i][j] = Double.parseDouble(stringTests[j]);
                }
            }
            System.out.println(Arrays.deepToString(marks));

            br.close();
        } catch (IOException e) {
            System.out.println("An IOException has occurred.");
        }

        // c)
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("result.txt"));
            double average = 0;

            bw.write("Student averages:\n");
            for (int i = 0; i < STUDENTS; i++){
                for (int j = 0; j < TESTS; j++){
                    average += marks[i][j];
                }
                average /= TESTS;

                averages[i] = average;
                bw.write(String.format("Student %d: %.2f%n", i, average));
                average = 0;
            }

            bw.close();
        } catch (IOException e) {
            System.out.println("An IOException has occurred");
        }

        // d)
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("result.txt", true));
            double highestMark = -1;
            int highestStudent = 0;

            for (int i = 0; i < STUDENTS; i++) {
                double mark = averages[i];
                if (mark > highestMark) {
                    highestMark = mark;
                    highestStudent = i;
                }
            }

            bw.write("Student with the highest average: " + highestStudent);
            bw.newLine();
            bw.newLine();

            bw.close();
        } catch (IOException e) {
            System.out.println("An IOException has occurred");
        }

        // e)
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("result.txt", true));

            double average = 0;

            bw.write("Class averages: \n");
            for (int i = 0; i < TESTS; i++){
                for (int j = 0; j < STUDENTS; j++){
                    average += marks[j][i];
                }
                average /= STUDENTS;

                bw.write(String.format("Test %d: %.2f%n", i, average));
                average = 0;
            }

            bw.close();
        } catch (IOException e) {
            System.out.println("An IOException has occurred");
        }



    }
}