import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReverseLines {
    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("reverse.txt"));
            int lineCount = Integer.parseInt(br.readLine());
            String[] lines = new String[lineCount];

            for (int i = 0; i < lineCount; i++){
                lines[i] = br.readLine();
            }

            for (int i = lines.length - 1; i >= 0; i--){
                System.out.println(lines[i]);
            }

        } catch (IOException e) {
            System.out.println("An IOException has occurred.");
        }
    }
}
