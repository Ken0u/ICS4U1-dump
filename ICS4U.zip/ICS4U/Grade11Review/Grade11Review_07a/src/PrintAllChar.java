import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class PrintAllChar {
    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("allChar.txt"));
            int charCode = br.read();
            char letter;

            while (charCode != -1) {
                letter = (char) charCode;

                if (letter != '\n' && letter != '\r' && letter != ' ') {
                    System.out.println(letter);
                }
                charCode = br.read();
            }
        } catch (IOException e) {
            System.out.println("An IOException has occurred.");
        }
    }
}
