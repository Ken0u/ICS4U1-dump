import java.util.Scanner;

public class Characters {
    public static void main(String[] args) {
        int uppercase = 0;
        char largestCharacter = 0, input;
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter 's' or 'S' to exit!");
        System.out.print("Enter a character: ");
        input = sc.nextLine().charAt(0);

        while (input != 's' && input != 'S') {
            if (input >= 'A' && input <='Z') {
                uppercase++;
            }
            if (input > largestCharacter) {
                largestCharacter = input;
            }

            System.out.print("Enter a character: ");
            input = sc.nextLine().charAt(0);
        }

        System.out.println(uppercase + " characters are uppercase");
        System.out.println("The largest character is " + largestCharacter);
    }
}
