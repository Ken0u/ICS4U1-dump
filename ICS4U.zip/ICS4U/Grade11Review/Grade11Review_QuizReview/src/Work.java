import java.util.*;
public class Work {
    public static void main(String[] args) {
        final int YEAR = 365, PEOPLE = 2;
        int msJacksonDays, mrsJacksonDays;
        double msJacksonPercentage, mrsJacksonPercentage, average;
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter days working for Ms. Jackson: ");
        msJacksonDays = sc.nextInt();
        System.out.print("Enter days working for Mrs. Jackson: ");
        mrsJacksonDays = sc.nextInt();

        msJacksonPercentage = (double) msJacksonDays / YEAR * 100;
        mrsJacksonPercentage = (double) mrsJacksonDays / YEAR * 100;
        average = (msJacksonPercentage + mrsJacksonPercentage) / PEOPLE;

        System.out.println("# of days worked");
        System.out.println("Ms. Jackson: " + msJacksonDays);
        System.out.println("Mrs. Jackson: " + mrsJacksonDays);
        System.out.println("Ms. Jackson: " + msJacksonPercentage + "%");
        System.out.println("Mrs. Jackson: " + mrsJacksonPercentage+ "%");
        System.out.println("Average: " + average + "%");

    }
}