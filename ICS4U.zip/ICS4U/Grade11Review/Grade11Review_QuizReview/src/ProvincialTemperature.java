import java.util.Scanner;

public class ProvincialTemperature {
    public static void main(String[] args) {
        final int MONTH = 12;
        final int PROVINCE = 13;
        Scanner sc = new Scanner(System.in);

        String[] names = new String[PROVINCE];
        double [][] temperatures = new double[PROVINCE][MONTH];

        names[0] = "Ontario";
        names[1] = "Quebec";
        names[2] = "Manitoba";

        for (int i = 0; i < 3; i++){
            System.out.print("Enter temperatures for " + names[i] + "\n");
            for (int j = 0; j < MONTH; j++){
                System.out.print("Enter average temperature for month " + (j + 1) + ": ");
                temperatures[i][j] = sc.nextDouble();
            }
        }
        sc.nextLine();

        double coldestTemperature = Double.MAX_VALUE;
        int coldestMonth = 1;
        int province = -1;
        String query;

        System.out.print("Enter name of province: ");
        query = sc.nextLine();

        for (int i = 0; i < PROVINCE && province == -1; i++){
            if (query.equals(names[i])) {
                province = i;
            }
        }

        if (province != -1) {
            for (int i = 0; i < MONTH; i++){
                if (temperatures[province][i] < coldestTemperature) {
                    coldestTemperature = temperatures[province][i];
                    coldestMonth = i + 1;
                }
            }

            System.out.println("Coldest month is " + coldestMonth);
        } else
            System.out.println("Province not found");

    }
}
