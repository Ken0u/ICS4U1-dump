import java.util.Scanner;

public class Division {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input;
        int numerator = 0, divisor = 0, answer;
        boolean quit = false;
        boolean goodInput = false;

        while (!quit) {
            while (!goodInput){
                try {
                    System.out.print("Enter the numerator: ");
                    input = sc.nextLine();

                    if (input.startsWith("q") || input.startsWith("Q")) {
                        quit = true;
                    } else {
                        numerator = Integer.parseInt(input);
                    }
                    goodInput = true;
                } catch (NumberFormatException e) {
                    System.out.println("You entered bad data.");
                    System.out.println("Please try again.");
                    System.out.println();
                }
            }

            goodInput = false;
            while (!goodInput && !quit) {
                try {
                    System.out.print("Enter the divisor: ");
                    input = sc.nextLine();

                    divisor = Integer.parseInt(input);
                    goodInput = true;
                } catch (NumberFormatException e) {
                    System.out.println("You entered bad data.");
                    System.out.println("Please try again.");
                    System.out.println();
                }
            }

            goodInput = false;
            if (!quit) {
                try {
                    answer = numerator / divisor;
                    System.out.println(numerator + " / " + divisor + " is " + answer);
                } catch (ArithmeticException e) {
                    System.out.println("You can't divide " + numerator + " by " + divisor);
                }
                System.out.println();
            }

        }

    }
}