import java.io.*;
public class GroupOfNumbers {
    public static void main(String[] args) {
        int sum = 0;
        String input;
        String groupName;

        try {
            BufferedReader br = new BufferedReader(new FileReader("input.txt"));

            input = br.readLine();
            groupName = input;

            input = br.readLine();

            while (input != null) {
                try {
                    sum += Integer.parseInt(input);
                } catch (NumberFormatException e) {
                    System.out.println(groupName);
                    System.out.println("Sum = " + sum);

                    groupName = input;

                    sum = 0;
                    System.out.println();
                }
                input = br.readLine();

            }
            System.out.println(groupName);
            System.out.println("Sum = " + sum);

        } catch (IOException e) {
            System.out.println("An IOException has occurred");
        }
    }
}
