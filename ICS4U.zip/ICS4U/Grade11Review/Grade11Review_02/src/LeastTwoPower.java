import java.util.Arrays;
import java.util.Scanner;

public class LeastTwoPower {
    public static void main(String[] args) {
        int input, exponent = 0, smallestPowerOfTwo = 1;
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a positive integer: ");
        input = sc.nextInt();

        while (smallestPowerOfTwo < input) {
            smallestPowerOfTwo *= 2;
            exponent++;
        }

        System.out.printf("The smallest power of 2 greater than or equal to %d is %d.%n", input, exponent);
    }
}
