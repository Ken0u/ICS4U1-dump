import java.util.Scanner;

public class Pythagorean{
    public static void main(String[] args) {
        int threshold;
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a positive integer: ");
        threshold = sc.nextInt();

        for (int a = 0; a <= threshold; a++){
            for (int b = a + 1; b <= threshold; b++){
                for (int c = b + 1; c <= threshold; c++){
                    if (a * a + b * b == c * c) {
                        System.out.printf("%d %d %d%n", a, b, c);
                    }
                }
            }
        }

    }
}
