public class Paper {
    public static void main(String[] args) {
        final int STACK_COUNT = 40;
        double area = 1, thickness = 0.090; // m^2 and mm

        System.out.printf("Starting area: %.2f m^2%n", area);
        System.out.printf("Starting thickness: %.2f mm%n", thickness);

        for (int i = 0; i < STACK_COUNT; i++){
            area /= 2;
            thickness *= 2;
        }

        System.out.printf("Ending area: %e m^2%n", area);
        System.out.printf("Ending thickness: %e mm%n", thickness);
    }
}
