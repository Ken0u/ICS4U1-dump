import java.util.Scanner;

public class SortThreeLetters {
    public static void main(String[] args) {
        char a, b, c;
        Scanner sc = new Scanner(System.in);

        a = sc.nextLine().charAt(0);
        b = sc.nextLine().charAt(0);
        c = sc.nextLine().charAt(0);

        if (a >='a' && a <='z' && b >='a' && b <='z' && c >='a' && c <='z'){
            if (a <= b && b <= c) {
                System.out.printf("%c %c %c", a, b, c);
            } else if (a <= c && c <= b) {
                System.out.printf("%c %c %c", a, c, b);
            } else if (b <= a && a <= c) {
                System.out.printf("%c %c %c", b, a, c);
            } else if (b <= c && c <= a) {
                System.out.printf("%c %c %c", b, c, a);
            } else if (c <= a && a <= b) {
                System.out.printf("%c %c %c", c, a, b);
            } else {
                System.out.printf("%c %c %c", c, b, a);
            }
        } else {
            System.out.println("All letters must be lowercase.");
        }
    }
}