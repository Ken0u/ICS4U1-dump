import java.util.Scanner;

public class Marks {
    public static void main(String[] args) {
        final int MINIMUM_TOTAL_SCORE = 90;
        final int MINIMUM_WRITING = 25;
        final int MINIMUM_SPEAKING = 25;
        int reading, listening, speaking, writing, totalScore;
        Scanner sc = new Scanner(System.in);

        System.out.print("Reading: ");
        reading = sc.nextInt();
        System.out.print("Listening: ");
        listening = sc.nextInt();
        System.out.print("Speaking: ");
        speaking = sc.nextInt();
        System.out.print("Writing: ");
        writing = sc.nextInt();

        totalScore = reading + listening + speaking + writing;

        if (totalScore >= MINIMUM_TOTAL_SCORE && writing >= MINIMUM_WRITING && speaking >= MINIMUM_SPEAKING) {
            System.out.println("The minimum requirement is met.");
        } else {
            System.out.println("The minimum requirement is not met.");
        }
    }
}