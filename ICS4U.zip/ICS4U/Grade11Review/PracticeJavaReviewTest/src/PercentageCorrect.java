import java.io.IOException;
import java.util.Scanner;

public class PercentageCorrect {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String line;
        int correct = 0, total = 0;
        double percentageCorrect;

        line = sc.nextLine();

        while (!line.equals("quit")) {
            total++;
            try {
                Integer.parseInt(line);
                correct++;
            } catch (NumberFormatException ignored) {

            }
            line = sc.nextLine();
        }

        percentageCorrect = (double) correct / total * 100;
        System.out.println(percentageCorrect + "% of the lines are correct.");
    }
}
