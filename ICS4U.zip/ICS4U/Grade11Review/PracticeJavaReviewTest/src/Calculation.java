import java.util.Scanner;

public class Calculation {
    public static void main(String[] args) {
        Calculation calc = new Calculation();
        Scanner sc = new Scanner(System.in);
        double bunnyDistance, bunnySpeed, turtleDistance, turtleSpeed, bunnyTime, turtleTime;

        System.out.println("Bunny: ");
        System.out.print("Distance between home and mall: ");
        bunnyDistance = sc.nextDouble();
        System.out.print("Speed: ");
        bunnySpeed = sc.nextDouble();
        System.out.println("Turtle: ");
        System.out.print("Distance between home and mall: ");
        turtleDistance = sc.nextDouble();
        System.out.print("Speed: ");
        turtleSpeed = sc.nextInt();

        bunnyTime = calc.time(bunnyDistance, bunnySpeed);
        turtleTime = calc.time(turtleDistance, turtleSpeed);

        if (bunnyTime > turtleTime){
            System.out.println("Turtle gets to the mall earlier.");
        } else {
            System.out.println("Bunny gets to the mall earlier.");
        }
    }

    public double time(double distance, double speed) {
        return distance / speed;
    }
}
