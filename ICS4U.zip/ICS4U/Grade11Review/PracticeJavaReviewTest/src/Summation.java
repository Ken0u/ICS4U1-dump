import java.util.Scanner;

public class Summation {
    public static void main(String[] args) {
        int x, n, sum = 0;
        Scanner sc =new Scanner(System.in);

        System.out.print("X: ");
        x = sc.nextInt();
        System.out.print("N: ");
        n = sc.nextInt();

        for (int i = 1; i <= n; i++){
            int exponent = i * 2;
            sum += Math.pow(x, exponent - 1) - Math.pow(x, exponent);
        }

        System.out.println(sum);
    }
}
