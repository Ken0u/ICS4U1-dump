import java.io.*;

public class ReverseLines {
    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("data.txt"));
            BufferedWriter bw = new BufferedWriter(new FileWriter("result.txt"));

            String line = br.readLine();

            while (line != null) {
                for (int i = line.length() - 1; i >= 0; i--) {
                    bw.write(""+line.charAt(i));
                }
                bw.newLine();
                line = br.readLine();
            }

            bw.close();
            br.close();

        } catch (IOException e) {
            System.out.println("An IOException has occurred.");
        }
    }
}
