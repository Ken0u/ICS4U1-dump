import java.util.Arrays;
import java.util.Scanner;

public class Reverse {
    public static void main(String[] args) {
        final int SIZE = 14;
        Scanner sc = new Scanner(System.in);
        int[] array = new int[SIZE];

        // a)
        int[] reversedArray = new int[SIZE];

        for (int i = 0; i < SIZE; i++){
            array[i] = sc.nextInt();
        }

        System.out.println("Enter 14 integers:");
        for (int i = 0; i < SIZE; i++) {
            reversedArray[SIZE - 1 - i] = array[i];
        }
        System.out.println(Arrays.toString(array));
        System.out.println(Arrays.toString(reversedArray));

        // b)
        System.out.println("Enter 14 integers:");
        for (int i = 0; i < SIZE; i++){
            array[i] = sc.nextInt();
        }

        System.out.println(Arrays.toString(array));
        for (int i = 0; i < SIZE / 2; i++) {
            int temp;
            temp = array[i];
            array[i] = array[SIZE - 1 - i];
            array[SIZE - 1 - i] = temp;
        }
        System.out.println(Arrays.toString(array));
    }
}
