import java.util.Arrays;
import java.util.Scanner;

public class Simple1DArray {
    public static void main(String[] args) {
        // a)
        int size;
        int[] array;
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter size of array: ");
        size = sc.nextInt();
        array = new int[size];
        System.out.println("a) " + Arrays.toString(array));

        // b)
        for (int i = 0; i < size; i++){
            array[i] = 1;
        }
        System.out.println("b) " + Arrays.toString(array));

        //c)
        System.out.printf("Enter %d integers%n", size);
        for (int i = 0; i < size; i++){
            array[i] = sc.nextInt();
        }
        System.out.println("c) " + Arrays.toString(array));

        // d)
        int temp;
        temp = array[0];
        array[0] = array[size - 1];
        array[size - 1] = temp;
        System.out.println("d) " + Arrays.toString(array));

        // e)
        for (int i = 0; i < size; i++) {
            if (array[i] < 0) {
                array[i] = -array[i];
            }
        }
        System.out.println("e) " + Arrays.toString(array));

        // f)
        int sampleSum = 0;
        for (int i = 0; i < size; i++){
            sampleSum += array[i];
        }
        System.out.println("f) " + sampleSum);

        // g)
        for (int i = 0; i < size; i++){
            if (array[i] % 2 == 0) {
                System.out.print(array[i] + " ");
            }
        }

    }
}