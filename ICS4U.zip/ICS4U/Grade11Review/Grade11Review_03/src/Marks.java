import java.io.Console;
import java.util.Arrays;
import java.util.Scanner;

public class Marks {
    public static void main(String[] args) {
        final int STUDENTS, TESTS;
        Scanner sc = new Scanner(System.in);

        // a)
        System.out.print("Enter the number of students: ");
        STUDENTS = sc.nextInt();
        System.out.print("Enter the number of tests: ");
        TESTS = sc.nextInt();
        double[][] marks = new double[STUDENTS][TESTS];

        // b)
        for (int i = 0; i < STUDENTS; i++) {
            System.out.printf("Enter grades for student #%d%n", i);
            for (int j = 0; j < TESTS; j++) {
                System.out.printf("Enter grade for test %d: ", j);
                marks[i][j] = sc.nextDouble();
            }
        }

        // c)
        double[] averages = new double[STUDENTS];
        for (int i = 0; i < STUDENTS; i++) {
            for (int j = 0; j < TESTS; j++) {
                averages[i] += marks[i][j];
            }
            averages[i] /= TESTS;
            System.out.printf("Average for student %d is: %.2f%n", i, averages[i]);
        }

        // d)
        double highestAverage = -1;
        int highestAverageStudent = 0;
        for (int i = 0; i < STUDENTS; i++) {
            if (averages[i] > highestAverage) {
                highestAverage = averages[i];
                highestAverageStudent = i;
            }
        }
        System.out.printf("Student %d has the highest average.%n", highestAverageStudent);

        // e)
        double classAverage = 0;
        for (double average : averages) {
            classAverage += average;
        }
        classAverage /= STUDENTS;

        System.out.println("Students higher than the class average:");
        for (int i = 0; i < STUDENTS; i++) {
            if (averages[i] > classAverage) {
                System.out.printf("Student #%d%n", i);
            }
        }


    }
}
