public abstract class Component {
    protected static final char EMPTY_SPACE = ' ';
    protected static final String NEW_LINE = "\n";
    protected static final int PADDING = 2;

    // justify options
    protected static final int LEFT_JUSTIFY = 0;
    protected static final int RIGHT_JUSTIFY = 1;
    protected static final int CENTER_JUSTIFY = 2;

    protected abstract String formatContent(int tableWidth);
    protected abstract String topDivider(int tableWidth);
    protected abstract String bottomDivider(int tableWidth);
    protected static String wrapAllLines(String value) {
        String[] lines = value.split(NEW_LINE);
        StringBuilder sb = new StringBuilder();

        for (String line: lines) {
            sb.append(Table.VERTICAL).append(EMPTY_SPACE).append(line).append(EMPTY_SPACE).append(Table.VERTICAL).append(NEW_LINE);
        }

        return sb.toString();
    }
    protected static String justifyLine(String toJustify, int justifyType, int width) {
        String justifiedLine;

        switch (justifyType) {
            case LEFT_JUSTIFY -> justifiedLine = String.format("%-" + width + "s", toJustify);
            case RIGHT_JUSTIFY -> justifiedLine = String.format("%" + width + "s", toJustify);
            case CENTER_JUSTIFY -> {
                int spaces = width - toJustify.length();
                int leftSpaces = spaces / 2;
                int rightSpaces = spaces - leftSpaces;

                justifiedLine = String.format("%" + leftSpaces + "s%s%" + rightSpaces + "s", "", toJustify, "");
            }
            default -> throw new IllegalArgumentException("Unexpected value: " + justifyType);
        }

        if (justifiedLine.length() > width) {
            return justifiedLine.substring(0, width - 3) + "...";
        }
        return justifiedLine;
    }

    protected static String justifyAllLines(String toJustify, int justifyType, int width) {
        String[] lines = toJustify.split(NEW_LINE);
        StringBuilder padded = new StringBuilder();

        for (int i = 0; i < lines.length; i++) {
            String justifiedLine = justifyLine(lines[i], justifyType, width);
            padded.append(justifiedLine);

            if (i < lines.length - 1) {
                padded.append(NEW_LINE);
            }
        }

        return padded.toString();
    }
}
