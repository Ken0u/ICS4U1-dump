public class HeaderedKeyValueComponent extends Component {
    private static final String DELIMITER = ":";
    public static final int EXTRA_PADDING = 3;
    private String header;
    private int headerJustifyType;
    private int headerKeyValueRatio;
    private String value;
    private int keyJustifyType;
    private int keyWidthRatio;
    private int valueJustifyType;
    private int valueWidthRatio;

    public HeaderedKeyValueComponent(String header, int headerJustifyType, int headerKeyValueRatio, String value, int keyJustifyType, int keyWidthRatio, int valueJustifyType, int valueWidthRatio) {
        this.header = header;
        this.headerJustifyType = headerJustifyType;
        this.value = value;
        this.keyJustifyType = keyJustifyType;
        this.keyWidthRatio = keyWidthRatio;
        this.valueJustifyType = valueJustifyType;
        this.valueWidthRatio = valueWidthRatio;
        this.headerKeyValueRatio = headerKeyValueRatio;
    }

    public String getHeader() {
        return header;
    }

    public int getHeaderJustifyType() {
        return headerJustifyType;
    }

    public int getHeaderKeyValueRatio() {
        return headerKeyValueRatio;
    }

    public String getValue() {
        return value;
    }

    public int getKeyJustifyType() {
        return keyJustifyType;
    }

    public int getKeyWidthRatio() {
        return keyWidthRatio;
    }

    public int getValueJustifyType() {
        return valueJustifyType;
    }

    public int getValueWidthRatio() {
        return valueWidthRatio;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public void setHeaderJustifyType(int headerJustifyType) {
        this.headerJustifyType = headerJustifyType;
    }

    public void setHeaderKeyValueRatio(int headerKeyValueRatio) {
        this.headerKeyValueRatio = headerKeyValueRatio;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setKeyJustifyType(int keyJustifyType) {
        this.keyJustifyType = keyJustifyType;
    }

    public void setKeyWidthRatio(int keyWidthRatio) {
        this.keyWidthRatio = keyWidthRatio;
    }

    public void setValueJustifyType(int valueJustifyType) {
        this.valueJustifyType = valueJustifyType;
    }

    public void setValueWidthRatio(int valueWidthRatio) {
        this.valueWidthRatio = valueWidthRatio;
    }

    @Override
    protected String topDivider(int tableWidth) {
        int dividerIndex = dividerIndex(tableWidth - EXTRA_PADDING);
        return Table.TOP_LEFT
                + Character.toString(Table.HORIZONTAL).repeat(dividerIndex + 1)
                + Table.T_DOWN_INTERSECTION
                + Character.toString(Table.HORIZONTAL).repeat(tableWidth - dividerIndex)
                + Table.TOP_RIGHT + NEW_LINE;
    }
    @Override
    protected String bottomDivider(int tableWidth) {
        int dividerIndex = dividerIndex(tableWidth - EXTRA_PADDING);
        return Table.BOTTOM_LEFT
                + Character.toString(Table.HORIZONTAL).repeat(dividerIndex + 1)
                + Table.T_UP_INTERSECTION
                + Character.toString(Table.HORIZONTAL).repeat(tableWidth - dividerIndex)
                + Table.BOTTOM_RIGHT + NEW_LINE;
    }

    private String justifyContent(int tableWidth) {
        tableWidth -= EXTRA_PADDING; // can no longer use space taken up by vertical divider and spacing around it

        double totalKeyValueWidthRatio =  keyWidthRatio + valueWidthRatio;
        double totalHeaderKeyValueWidthRatio = headerKeyValueRatio + totalKeyValueWidthRatio;

        int headerWidth = (int) (tableWidth * (headerKeyValueRatio / totalHeaderKeyValueWidthRatio));
        int keyValueWidth = tableWidth - headerWidth;

        int keyWidth = (int) (keyValueWidth * (keyWidthRatio / totalKeyValueWidthRatio));
        int valueWidth = keyValueWidth - keyWidth;

        String[] lines = value.split(NEW_LINE);

        StringBuilder sb = new StringBuilder();
        String headerJustified = justifyLine(header, headerJustifyType, headerWidth);
        sb.append(headerJustified);

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            int indexOfDelimiter = line.indexOf(DELIMITER);

            String key = line.substring(0, indexOfDelimiter);
            String value = line.substring(indexOfDelimiter + 1);

            if (i > 0) {
                sb.append(Character.toString(EMPTY_SPACE).repeat(headerJustified.length()));
            }
            sb.append(EMPTY_SPACE).append(Table.VERTICAL).append(EMPTY_SPACE);
            sb.append(justifyLine(key, keyJustifyType, keyWidth));
            sb.append(justifyLine(value, valueJustifyType, valueWidth));

            if (i < lines.length - 1) {
                sb.append(NEW_LINE);
            }
        }

        return sb.toString();
    }

    protected int dividerIndex(int tableWidth) {
        double totalHeaderKeyValueWidthRatio = headerKeyValueRatio + keyWidthRatio + valueWidthRatio;
        return (int) (tableWidth * (headerKeyValueRatio / totalHeaderKeyValueWidthRatio)) + 1;
    }

    @Override
    protected String formatContent(int tableWidth) {
        return wrapAllLines(justifyContent(tableWidth));
    }
}
