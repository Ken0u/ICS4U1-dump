public class KeyValueComponent extends Component {
    private static final String DELIMITER = ":";
    private String value;
    private int keyJustifyType;
    private int keyWidthRatio;
    private int valueJustifyType;
    private int valueWidthRatio;

    public KeyValueComponent(String value, int keyJustifyType, int keyWidthRatio, int valueJustifyType, int valueWidthRatio) {
        this.value = value;
        this.keyJustifyType = keyJustifyType;
        this.keyWidthRatio = keyWidthRatio;
        this.valueJustifyType = valueJustifyType;
        this.valueWidthRatio = valueWidthRatio;
    }

    public String getValue() {
        return value;
    }

    public int getKeyJustifyType() {
        return keyJustifyType;
    }

    public int getKeyWidthRatio() {
        return keyWidthRatio;
    }

    public int getValueJustifyType() {
        return valueJustifyType;
    }

    public int getValueWidthRatio() {
        return valueWidthRatio;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setKeyJustifyType(int keyJustifyType) {
        this.keyJustifyType = keyJustifyType;
    }

    public void setKeyWidthRatio(int keyWidthRatio) {
        this.keyWidthRatio = keyWidthRatio;
    }

    public void setValueJustifyType(int valueJustifyType) {
        this.valueJustifyType = valueJustifyType;
    }

    public void setValueWidthRatio(int valueWidthRatio) {
        this.valueWidthRatio = valueWidthRatio;
    }

    @Override
    protected String topDivider(int tableWidth) {
        return Table.TOP_LEFT
                + Character.toString(Table.HORIZONTAL).repeat(tableWidth + PADDING)
                + Table.TOP_RIGHT + NEW_LINE;
    }

    @Override
    protected String bottomDivider(int tableWidth) {
        return Table.BOTTOM_LEFT
                + Character.toString(Table.HORIZONTAL).repeat(tableWidth + PADDING)
                + Table.BOTTOM_RIGHT + NEW_LINE;
    }

    private String justifyContent(int tableWidth) {
        double totalWidthRatio = (double) keyWidthRatio + valueWidthRatio;

        int keyWidth = (int) (tableWidth * (keyWidthRatio / totalWidthRatio));
        int valueWidth = tableWidth - keyWidth;

        String[] lines = value.split(NEW_LINE);

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            System.out.println(line);
            int indexOfDelimiter = line.indexOf(DELIMITER);

            System.out.println(indexOfDelimiter);

            String key = line.substring(0, indexOfDelimiter);
            String value = line.substring(indexOfDelimiter + 1);

            sb.append(justifyLine(key, keyJustifyType, keyWidth));
            sb.append(justifyLine(value, valueJustifyType, valueWidth));

            if (i < lines.length - 1) {
                sb.append(NEW_LINE);
            }
        }

        return sb.toString();
    }

    @Override
    protected String formatContent(int tableWidth) {
        return wrapAllLines(justifyContent(tableWidth));
    }
}
