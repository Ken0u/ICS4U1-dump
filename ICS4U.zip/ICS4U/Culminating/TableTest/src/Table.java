import java.util.ArrayList;
import java.util.List;

public class Table {
    protected static final char TOP_LEFT = '┌';
    protected static final char TOP_RIGHT = '┐';
    protected static final char BOTTOM_LEFT = '└';
    protected static final char BOTTOM_RIGHT = '┘';
    protected static final char HORIZONTAL = '─';
    protected static final char VERTICAL = '│';
    protected static final char T_RIGHT_INTERSECTION = '├';
    protected static final char T_LEFT_INTERSECTION = '┤';
    protected static final char T_DOWN_INTERSECTION = '┬';
    protected static final char T_UP_INTERSECTION = '┴';
    protected static final char INTERSECTION = '┼';
    private List<Component> components;
    private int width;

    public Table(int width) {
        components = new ArrayList<>();
        this.width = width;
    }

    public void addComponent(Component component) {
        components.add(component);
    }

    public List<Component> getComponents() {
        return components;
    }

    public int getWidth() {
        return width;
    }

    public void setComponents(List<Component> components) {
        this.components = components;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    @Override
    public String toString() {
        if (components.isEmpty()) return "";

        StringBuilder sb = new StringBuilder();

        if (components.size() == 1) {
            return sb.append(components.getFirst().formatContent(width)).toString();
        }

        String previousDivider = "";
        for (int i = 0; i < components.size(); i++) {
            Component component = components.get(i);

            sb.append(combineDividers(previousDivider, component.topDivider(width)));
            sb.append(component.formatContent(width));

            previousDivider = component.bottomDivider(width);
            if (i == components.size() - 1) {
                sb.append(previousDivider);
            }
        }

        return sb.toString();
    }

    private String combineDividers(String previousDivider, String nextDivider) {
        if (previousDivider.isEmpty()) return nextDivider;

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < previousDivider.length(); i++) {
            char previousDividerCharacter = previousDivider.charAt(i);
            char nextDividerCharacter = nextDivider.charAt(i);

            if (previousDividerCharacter == HORIZONTAL) {
                sb.append(nextDividerCharacter);
            } else if (nextDividerCharacter == HORIZONTAL) {
                sb.append(previousDividerCharacter);
            } else if (previousDividerCharacter == BOTTOM_LEFT && nextDividerCharacter == TOP_LEFT) {
                sb.append(T_RIGHT_INTERSECTION);
            } else if (previousDividerCharacter == BOTTOM_RIGHT && nextDividerCharacter == TOP_RIGHT) {
                sb.append(T_LEFT_INTERSECTION);
            } else if (previousDividerCharacter == T_UP_INTERSECTION && nextDividerCharacter == T_DOWN_INTERSECTION) {
                sb.append(INTERSECTION);
            } else {
                sb.append(nextDividerCharacter);
            }
        }

        return sb.toString();
    }

    public void render() {
        System.out.println(this);
    }
}
