public class Main {
    public static void main(String[] args) {
        SimpleComponent box = new SimpleComponent("Order #10025", Component.CENTER_JUSTIFY);
        Component box2 = new KeyValueComponent("""
                Current Status: Not started
                Quantity: 1
                Date Ordered: Tue Jan 16 15:46:26 EST 2024
                Date to be Finished By: Tue Jan 23 15:46:26 EST 2024""", Component.LEFT_JUSTIFY, 2, Component.LEFT_JUSTIFY, 3);
        SimpleComponent box3 = new SimpleComponent("Quantity: 1", Component.LEFT_JUSTIFY);
        SimpleComponent box4 = new SimpleComponent("Date Ordered: Tue Jan 16 15:46:26 EST 2024", Component.LEFT_JUSTIFY);
        SimpleComponent box5 = new SimpleComponent("Date to be Finished By: Tue Jan 23 15:46:26 EST 2024", Component.LEFT_JUSTIFY);
        Component test = new HeaderedKeyValueComponent("Test", Component.CENTER_JUSTIFY, 1, "TEst: TEst\nTest: TEst", Component.LEFT_JUSTIFY, 1, Component.LEFT_JUSTIFY, 1);
        Component test2 = new HeaderedKeyValueComponent("Test", Component.CENTER_JUSTIFY, 1,
                """
                Additional Hardware:
                Storage: 1
                Storage: 2
                Storage: 3
                Storage: 4
                :
                Fans: ksjdfkjsdf""", Component.LEFT_JUSTIFY, 1,
                Component.LEFT_JUSTIFY, 1);

//        Component test3 = new KeyValueComponent(
//                """
//                Additional Hardware
//                Storage: 1
//                Storage: 2
//                Storage: 3
//                Storage: 4
//
//                Fans: ksjdfkjsdf""", Component.LEFT_JUSTIFY, 1,
//                Component.LEFT_JUSTIFY, 1);
        Table table = new Table(60);



        table.addComponent(box);
        table.addComponent(box2);
        table.addComponent(box3);
        table.addComponent(box4);
        table.addComponent(box5);
        table.addComponent(test);
        table.addComponent(test2);
        table.render();

//        System.out.printf("%20s%n", "dootz");
//        System.out.printf("%-20s%n", "dootz");
    }
}

//        System.out.println("""
//        ┌────────────────────────────────────────────────────────────────────┐
//        │ Order Details:                                                     │
//        │ ID:                         10025                                                          │
//        │ Current Status:             Not started                                        │
//        │ Quantity:                   1                                                        │
//        │ Date Ordered:               Tue Jan 16 15:46:26 EST 2024                         │
//        │ Date to be Finished By:     Tue Jan 23 15:46:26 EST 2024               │
//        ├────────────────────────────────────────────────────────────────────┤
//        │ Customer Information:                                              │
//        │ First Name: meherzad                                               │
//        │ Last Name: stanley                                                 │
//        │ Email: stanley@meherzad.com                                        │
//        │ Phone Number: 416-123-1234                                         │
//        │ Address: 111 Wellesley St W, Toronto, ON M7A 1A2, Canada           │
//        ├────────────────────────────────────────────────────────────────────┤
//        │ Shipping Information:                                              │
//        ├────────────────────────────────────────────────────────────────────┤
//        │ Billing Address: 111 Wellesley St W, Toronto, ON M7A 1A2, Canada   │
//        │ Shipping Address: 50 Francine Dr, North York, ON M2H 2G6, Canada   │
//        │ Shipping Company: canada post                                      │
//        ├────────────────────────────────────────────────────────────────────┤
//        │ Primary Hardware:                                                  │
//        ├─────────────────────────┬──────────────────────────────────────────┤
//        │ CPU                     │ Price:            $560.00                │
//        │                         │ Brand:            intel                  │
//        │                         │ Model:            i9-13900KF             │
//        │                         │ Processing Speed: 5.80GHz                │
//        ├─────────────────────────┼──────────────────────────────────────────┤
//        │  │ Motherboard          │ Price: $280.00                        │  │
//        │  │                      │ Brand: ASUS                           │  │
//        │  │                      │ Model: Prime Z790P WIFI               │  │
//        │  │                      │ Size: ATX                             │  │
//        │  │                      │ Wi-Fi Antenna: true                   │  │
//        │  ├──────────────────────┼───────────────────────────────────────┤  │
//        │  │ RAM                  │ Price: $145.00                        │  │
//        │  │                      │ Brand: Kingston Technology            │  │
//        │  │                      │ Model: Fury Beast                     │  │
//        │  │                      │ Type: DDR5                            │  │
//        │  │                      │ Memory: 32GB                          │  │
//        │  │                      │ Speed: 5200.0GHz                      │  │
//        │  ├──────────────────────┼───────────────────────────────────────┤  │
//        │  │ GPU                  │ Price: $930.00                        │  │
//                                  ┼───────────────────────────────────────│  │
//        │  │                      │ Brand:             Nvidia             │  │
//        │  │                      │ Model:             4070 Ti            │  │
//        │  │                      │ Has Ray Tracing:   true               │  │
//        │  │                      │ Clock Speed:       5.80GHz            │  │
//        │  │                      │ VRAM:              12GB               │  │
//        │  ├──────────────────────┼───────────────────────────────────────┤  │
//        │  │ Storage              │ Price: $61.00                         │  │
//        │  │                      │ Brand: Western Digital                │  │
//        │  │                      │ Model: SN570                          │  │
//        │  │                      │ Speed: 3500.0 MBps                    │  │
//        │  │                      │ Storage Size: 1 GB                    │  │
//        │  ├──────────────────────┼───────────────────────────────────────┤  │
//        │  │ Cooler               │ Price: $145.00                        │  │
//        │  │                      │ Brand: DeepCool                       │  │
//        │  │                      │ Model: LS720                          │  │
//        │  │                      │ Type: liquid                          │  │
//        │  │                      │ Number of Fans: 3                     │  │
//        │  ├──────────────────────┼───────────────────────────────────────┤  │
//        │  │ Power Supply         │ Price: $69.00                         │  │
//        │  │                      │ Brand: GIGABYTE                       │  │
//        │  │                      │ Model: GP-P605G                       │  │
//        │  │                      │ Wattage: 650.00W                      │  │
//        │  ├──────────────────────┼───────────────────────────────────────┤  │
//        │  │ Case                 │ Price: $61.00                         │  │
//        │  │                      │ Brand: DeepCool                       │  │
//        │  │                      │ Model: CH370                          │  │
//        │  │                      │ Color: black                          │  │
//        │  ├──────────────────────┼───────────────────────────────────────┤  │
//        │  │ Additional Hardware  │      ┌────────────────────┐           │  │
//        │  │                      │      │ Additional Storage │           │  │
//        │  │                      │      │ Price: $500.00     │           │  │
//        │  │                      │      │ Brand: Kingston    │           │  │
//        │  │                      │      │ Model: KC3000      │           │  │
//        │  │                      │      │ Speed: 3500.0 MBps │           │  │
//        │  │                      │      │ Storage Size: 1 GB │           │  │
//        │  │                      │      └────────────────────┘           │  │
//        │  │                      │ Has RGB Strips: true                  │  │
//        │  │                      │ Noise-Cancelling Fans: true           │  │
//        │  │                      │ Number of Extra Fans: 3               │  │
//        │  │                      │                                       │  │
//        │  └──────────────────────┴───────────────────────────────────────┘  │
//        └────────────────────────────────────────────────────────────────────┘
//        """);
//        String input = "Line 1\nLine 2\nLine 3";
//        String[] lines = input.split(System.lineSeparator());
//
//        for (String line : lines) {
//            String paddedLine = String.format("%" + 20 + "s", line);
//            System.out.println(paddedLine);
//        }
