public class SimpleComponent extends Component {
    private String value;
    private int justifyType;
    public SimpleComponent(String value, int justifyType) {
        this.value = value;
        this.justifyType = justifyType;
    }

    public String getValue() {
        return value;
    }

    public int getJustifyType() {
        return justifyType;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setJustifyType(int justifyType) {
        this.justifyType = justifyType;
    }

    @Override
    protected String topDivider(int tableWidth) {
        return Table.TOP_LEFT
                + Character.toString(Table.HORIZONTAL).repeat(tableWidth + PADDING)
                + Table.TOP_RIGHT + NEW_LINE;
    }

    @Override
    protected String bottomDivider(int tableWidth) {
        return Table.BOTTOM_LEFT
                + Character.toString(Table.HORIZONTAL).repeat(tableWidth + PADDING)
                + Table.BOTTOM_RIGHT + NEW_LINE;
    }

    @Override
    protected String formatContent(int tableWidth) {
        return wrapAllLines(justifyAllLines(value, justifyType, tableWidth));
    }
}
